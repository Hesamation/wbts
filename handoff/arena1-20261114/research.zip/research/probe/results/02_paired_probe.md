# Paired probe results (generated)

Generated 2026-11-14T06:30:09.421Z on nearcore 2.14.0 (protocol 88). Wasm sha256 `095fdf893814826401db91e8434e043bf27d67350738eab065e22a55f457de3d`.
Price 0.0500 NEAR, kill fee 0.0050, reveal bond 0.0050, deadline 40 blocks, window 20 blocks. Allegation policies use the handoff defaults (1 NEAR collateral, 0.25 NEAR bonds).

Net columns are credits minus deposits per party, in NEAR, gas excluded. "Exit ok" means every credit was withdrawn and the contract ledger balanced to zero.

| Case | Policy | What happens | Verdict (fault / reason) | Delegator net | Worker net | Watcher net | Txs | Tgas | Blocks open→settled | Payload bytes on chain | Exit ok |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| C1 | BinaryEscrow | success control: valid receipt for the committed request | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 2 | 4.958 | 3 | 0 | yes |
| C1 | EagerPublic | success control: valid receipt for the committed request | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 2 | 5.342 | 3 | 900 | yes |
| C1 | EagerHashOnly | success control: valid receipt for the committed request | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 2 | 5.151 | 3 | 0 | yes |
| C1 | RevealOnChallenge | success control: valid receipt for the committed request | NoFault / receipt_valid_acknowledged | -0.0500 | 0.0500 | 0.0000 | 3 | 7.152 | 6 | 0 | yes |
| C1w | RevealOnChallenge | success, delegator never acks: paid when the window elapses | NoFault / receipt_valid_window_elapsed | -0.0500 | 0.0500 | 0.0000 | 4 | 8.857 | 32 | 0 | yes |
| C1 | OptimisticAllegation | success control: completion anchored, no claim, collateral released after the filing window | NoFault / released_no_claim | 0.0000 | 0.0000 | 0.0000 | 4 | 8.295 | 32 | 0 | yes |
| C1 | CheckedAllegation | success control: completion anchored, no claim, collateral released after the filing window | NoFault / released_no_claim | 0.0000 | 0.0000 | 0.0000 | 4 | 8.338 | 32 | 0 | yes |
| C2 | BinaryEscrow | invalid input: worker has no path, job expires | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.081 | 49 | 0 | yes |
| C2 | EagerPublic | invalid input: worker reveals the committed bytes, evaluated at filing | DelegatorInput / stream_not_false | -0.0050 | 0.0050 | 0.0000 | 3 | 6.406 | 6 | 184 | yes |
| C2 | EagerHashOnly | invalid input: worker reveals the committed bytes, evaluated at filing | DelegatorInput / stream_not_false | -0.0050 | 0.0050 | 0.0000 | 3 | 6.375 | 6 | 184 | yes |
| C2 | RevealOnChallenge | invalid input: worker reveals the committed bytes, evaluated at filing | DelegatorInput / stream_not_false | -0.0050 | 0.0050 | 0.0000 | 3 | 6.409 | 6 | 184 | yes |
| C3a | BinaryEscrow | tampered response: one bit flipped, real signature attached | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.822 | 49 | 0 | yes |
| C3a | EagerPublic | tampered response: one bit flipped, real signature attached | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 7.017 | 49 | 0 | yes |
| C3a | EagerHashOnly | tampered response: one bit flipped, real signature attached | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.79 | 49 | 0 | yes |
| C3a | RevealOnChallenge | tampered response: one bit flipped, real signature attached | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.828 | 49 | 0 | yes |
| C3a | OptimisticAllegation | tampered response, TRUE allegation, unchallenged: settles as filed (evaluator never runs) | UncheckedBlameAccepted / unchallenged_allegation_final | 0.2000 | -0.2500 | 0.0000 | 5 | 10.532 | 35 | 0 | yes |
| C3a | CheckedAllegation | tampered response, TRUE allegation: evaluated and settled in the filing transaction | WorkerReceipt / signer_not_registered:0x4e5729166e942f8df17e2400a61fc3fad64ae378 | 0.2000 | -0.2500 | 0.0000 | 4 | 8.974 | 9 | 0 | yes |
| C3b | RevealOnChallenge | model substitution: job requires z-ai/glm-5.3-flash, worker delivers a real receipt from Qwen/Qwen3.8-27B | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.833 | 49 | 0 | yes |
| C3c | RevealOnChallenge | replay: a real receipt for a DIFFERENT request is delivered | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.828 | 49 | 0 | yes |
| C3d | EagerHashOnly | reuse: the same real receipt is presented for a second job with the same request hash | WorkerNoReceipt / no_valid_receipt_by_deadline | -0.0500 | 0.0500 | 0.0000 | 5 | 12.159 | 49 | 0 | yes |
| C3e | RevealOnChallenge | forged signer: an unregistered local key signs the correct text | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.828 | 49 | 0 | yes |
| C4a | EagerPublic | worker falsely claims invalid input on a valid request; then delivers | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 3 | 7.661 | 6 | 1085 | yes |
| C4a | EagerHashOnly | worker falsely claims invalid input on a valid request; then delivers | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 3 | 7.521 | 6 | 185 | yes |
| C4a | RevealOnChallenge | worker falsely claims invalid input on a valid request; then delivers | NoFault / receipt_valid_acknowledged | -0.0500 | 0.0500 | 0.0000 | 4 | 9.481 | 9 | 185 | yes |
| C4b | OptimisticAllegation | delegator falsely blames a VALID real receipt; nobody challenges in the window | UncheckedBlameAccepted / unchallenged_allegation_final | 0.2000 | -0.2500 | 0.0000 | 6 | 12.753 | 39 | 0 | yes |
| C4b | OptimisticAllegation | same false allegation; the accused worker challenges in time | FalseClaimByDelegator / allegation_overturned_on_challenge | -0.2500 | 0.2000 | 0.0000 | 5 | 11.078 | 12 | 0 | yes |
| C4b | OptimisticAllegation | same false allegation; a third-party watcher challenges in time | FalseClaimByDelegator / allegation_overturned_on_challenge | -0.2500 | 0.0000 | 0.2000 | 5 | 11.235 | 12 | 0 | yes |
| C4b | CheckedAllegation | same false allegation; evaluated at filing and disproved | NoFault / released_no_claim | 0.0000 | 0.0000 | 0.0000 | 5 | 11.067 | 35 | 0 | yes |
| C4c | RevealOnChallenge | delegator falsely claims the bytes were not delivered; worker reveals | FalseClaimByDelegator / bytes_revealed_match_receipt | -0.0550 | 0.0550 | 0.0000 | 5 | 11.52 | 12 | 900 | yes |
| C5a | BinaryEscrow | worker never delivers anything | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.031 | 49 | 0 | yes |
| C5a | EagerPublic | worker never delivers anything | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.035 | 49 | 0 | yes |
| C5a | EagerHashOnly | worker never delivers anything | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.063 | 49 | 0 | yes |
| C5a | RevealOnChallenge | worker never delivers anything | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.037 | 49 | 0 | yes |
| C5a | OptimisticAllegation | worker never delivers anything | NoFault / released_unfinished_no_fault | 0.0000 | 0.0000 | 0.0000 | 4 | 7.976 | 52 | 0 | yes |
| C5b | BinaryEscrow | valid receipt posted, response bytes withheld off-chain: delegator has no claim to file | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 3 | 7.162 | 3 | 0 | yes |
| C5b | EagerHashOnly | valid receipt posted, response bytes withheld off-chain: delegator has no claim to file | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 3 | 7.36 | 3 | 0 | yes |
| C5b | EagerPublic | withholding is impossible: delivery without the bytes is refused, job expires | WorkerNoReceipt / no_valid_receipt_by_deadline | 0.0000 | 0.0000 | 0.0000 | 3 | 6.111 | 49 | 0 | yes |
| C5b | RevealOnChallenge | valid receipt posted, bytes withheld: delegator challenges, worker stays silent | WorkerWithheld / response_bytes_not_revealed | 0.0000 | 0.0000 | 0.0000 | 4 | 9.042 | 32 | 0 | yes |
| S1 | EagerPublic | success with an 8192-byte response | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 2 | 6.761 | 3 | 8192 | yes |
| S1 | EagerHashOnly | success with an 8192-byte response | NoFault / receipt_valid | -0.0500 | 0.0500 | 0.0000 | 2 | 5.195 | 3 | 0 | yes |
| S2 | RevealOnChallenge | challenged delivery: worker reveals an 8192-byte response | FalseClaimByDelegator / bytes_revealed_match_receipt | -0.0550 | 0.0550 | 0.0000 | 4 | 11.038 | 9 | 8192 | yes |
| S3 | RevealOnChallenge | invalid-input claim revealing a 8199-byte request | DelegatorInput / stream_not_false | -0.0050 | 0.0050 | 0.0000 | 2 | 6.257 | 3 | 8199 | yes |

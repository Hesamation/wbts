#!/usr/bin/env bash
# Reproduce every executed claim in REPORT.md. Local only: no keys, no accounts, no spend, no deploy.
# Network use: crates.io, npm, PyPI, the nearcore sandbox binary (S3), Intel collateral (dcap-qvl),
# and read-only public RPC/API calls. Tested on Linux x86_64, Node 20, Python 3.13, 2 CPUs, 2 GB RAM.
#
#   ./reproduce.sh            # everything (about 15-20 minutes; the paired probe is ~12 of them)
#   SKIP_PROBE=1 ./reproduce.sh   # skip the long paired probe, keep its saved results
#   REFRESH_LIVE=1 ./reproduce.sh # also re-fetch the live inputs (attestation, prices, RPC)
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"
export RUSTUP_HOME="${RUSTUP_HOME:-$HOME/.local/rustup}" CARGO_HOME="${CARGO_HOME:-$HOME/.local/cargo}"
export PATH="$CARGO_HOME/bin:$PATH" CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-2}"

echo "== 1. toolchain"
if ! command -v cargo >/dev/null; then
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /tmp/rustup-init.sh
  sh /tmp/rustup-init.sh -y --profile minimal --default-toolchain stable --no-modify-path -t wasm32-unknown-unknown
fi
rustup target add wasm32-unknown-unknown >/dev/null
rustup component add rust-src >/dev/null
rustc --version

echo "== 2. contract"
# Three flags matter (each one was needed in this probe, see README.md "Build notes"):
#   --cfg near                      near-sdk >= 5.30 only uses host functions when this cfg is set
#   -C target-cpu=mvp + build-std   current Rust enables wasm features that nearcore 2.14 rejects
(cd contract && RUSTC_BOOTSTRAP=1 RUSTFLAGS="--cfg near -C link-arg=-s -C target-cpu=mvp" \
  cargo build -Zbuild-std=std,panic_abort --target wasm32-unknown-unknown --release --locked)
mkdir -p artifacts
cp contract/target/wasm32-unknown-unknown/release/receipt_escrow_probe.wasm artifacts/
sha256sum artifacts/receipt_escrow_probe.wasm

echo "== 3. harness and sandbox node"
(cd harness && npm ci --no-audit --no-fund >/dev/null)
SBX="$ROOT/harness/node_modules/near-sandbox/bin/near-sandbox"
if ! "$SBX" --version 2>/dev/null | grep -q "release 2.14.0"; then
  # near-workspaces 5.0.0 bundles nearcore 2.6.2 (protocol 77). Mainnet is on protocol 88, so use 2.14.0.
  curl -sS -L -o /tmp/near-sandbox-2.14.0.tar.gz \
    https://s3-us-west-1.amazonaws.com/build.nearprotocol.com/nearcore/Linux-x86_64/2.14.0/near-sandbox.tar.gz
  echo "a0ba004218b218bd74351795e7ce2eda4a2b6af5cd3e252bd5e8bfe3c8f2e691  /tmp/near-sandbox-2.14.0.tar.gz" | sha256sum -c -
  tar -xzf /tmp/near-sandbox-2.14.0.tar.gz -C /tmp
  cp /tmp/Linux-x86_64/near-sandbox "$SBX" && chmod +x "$SBX"
fi
"$SBX" --version | head -1

if [ "${REFRESH_LIVE:-0}" = "1" ]; then
  echo "== 3b. refresh live inputs"
  NONCE="$(openssl rand -hex 32)"; echo "nonce=$NONCE" > live/attestation_nonce.txt
  for algo in ecdsa ed25519; do
    curl -sS -G 'https://cloud-api.near.ai/v1/attestation/report' --data-urlencode 'model=Qwen/Qwen3.8-27B' \
      --data-urlencode 'provider=near' --data-urlencode 'include_tls_fingerprint=false' \
      --data-urlencode "signing_algo=$algo" --data-urlencode "nonce=$NONCE" \
      -H 'Accept: application/json' -H 'x-no-aliasing: true' -o "live/attestation_qwen38_$algo.json"
  done
  rpc() { curl -sS -X POST https://rpc.mainnet.fastnear.com -H 'Content-Type: application/json' -d "$1"; }
  rpc '{"jsonrpc":"2.0","id":"1","method":"EXPERIMENTAL_protocol_config","params":{"finality":"final"}}' > live/protocol_config_mainnet.json
  rpc '{"jsonrpc":"2.0","id":"1","method":"gas_price","params":[null]}' > live/gas_price_mainnet.json
  curl -sS 'https://cloud-api.near.ai/v1/model/list' > live/models.json
  curl -sS 'https://api.coingecko.com/api/v3/simple/price?ids=near&vs_currencies=usd&include_last_updated_at=true' > live/near_price_coingecko.json
fi

echo "== 4. evidence checks"
(cd harness && node 00_fixture_check.mjs >/dev/null && echo "fixtures: results/00_fixture_check.json")
python3 -m venv .venv >/dev/null && .venv/bin/pip install -q dcap-qvl==0.7.1
.venv/bin/python scripts/01_attestation_check.py >/dev/null && echo "attestation: results/01_attestation_check.json"

echo "== 5. paired probe"
(cd harness && node smoke.mjs | tail -6)
if [ "${SKIP_PROBE:-0}" != "1" ]; then
  (cd harness && NEAR_NO_LOGS=1 node run_probe.mjs > ../results/02_paired_probe.console.log 2>&1; tail -9 ../results/02_paired_probe.console.log)
fi
(cd harness && NEAR_NO_LOGS=1 node extra_checks.mjs | grep -E '"id"|"pass"')

echo "== 6. economics"
python3 scripts/03_economics.py >/dev/null && echo "economics: results/03_economics.json"
echo "done"

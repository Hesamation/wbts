# Provenance of the two receipt bundles in this directory

Copied byte-for-byte from https://github.com/tmdry4530/tee-receipts (MIT, see LICENSE),
commit 25cc88e01c9db037ad042c3bf3fa115646f627a0 (2026-11-02), paths
`fixtures/demo/receipt-bundle.json` and `fixtures/testnet/receipt-bundle.json`.

They are a third party's recordings of two NEAR AI Cloud chat completions made on 2026-11-01 with
model `Qwen/Qwen3.8-27B` (exact request bytes, exact response bytes, and the `GET /v1/signature`
JSON, `signature_kind: provider_tee`, `signing_algo: ecdsa`).

What this probe independently checked about them (see `results/00_fixture_check.json`):
- sha256(request bytes) and sha256(response bytes) equal the hashes in the signed text;
- the EIP-191 signature recovers to `0x835ab53d20294ef795906dff21ae4c045336aa26`;
- that address is the `signing_address` returned for `Qwen/Qwen3.8-27B` by
  `GET https://cloud-api.near.ai/v1/attestation/report` fetched by this probe on 2026-11-14
  with its own nonce (`live/attestation_qwen38_ecdsa.json`).

What was NOT checked here: who made the two calls, and anything about the content of the answers.
No NEAR AI API key was available, so no new completion was made for this probe.

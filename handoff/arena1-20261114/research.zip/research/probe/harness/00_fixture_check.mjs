// Off-chain check of the third-party receipt bundles against (a) their own bytes and
// (b) the signing address NEAR AI Cloud returned to THIS probe on 2026-11-14.
// No credentials, no network. Run from probe/harness: node 00_fixture_check.mjs
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { secp256k1 } from '@noble/curves/secp256k1';
import { keccak_256 } from '@noble/hashes/sha3';

const sha256hex = (b) => createHash('sha256').update(b).digest('hex');
const hex = (u8) => Buffer.from(u8).toString('hex');

export function eip191Hash(text) {
  const msg = Buffer.from(text, 'utf8');
  return keccak_256(Buffer.concat([Buffer.from(`\x19Ethereum Signed Message:\n${msg.length}`, 'utf8'), msg]));
}
export function recoverAddress(text, sigHex) {
  const sig = Buffer.from(sigHex.replace(/^0x/, ''), 'hex');
  if (sig.length !== 65) throw new Error('signature must be 65 bytes');
  const v = sig[64] >= 27 ? sig[64] - 27 : sig[64];
  const s = secp256k1.Signature.fromCompact(sig.subarray(0, 64)).addRecoveryBit(v);
  const pub = s.recoverPublicKey(eip191Hash(text)).toRawBytes(false).subarray(1);
  return '0x' + hex(keccak_256(pub).subarray(12));
}

const live = JSON.parse(readFileSync('../live/attestation_qwen38_ecdsa.json', 'utf8'));
const liveModelSigners = (live.model_attestations || []).map((m) => m.signing_address.toLowerCase());
const out = {
  checked_at: new Date().toISOString(),
  live_attestation: {
    file: 'probe/live/attestation_qwen38_ecdsa.json',
    sha256: sha256hex(readFileSync('../live/attestation_qwen38_ecdsa.json')),
    model: (live.model_attestations || [])[0]?.model_name,
    model_signing_addresses: liveModelSigners,
    gateway_signing_address: live.gateway_attestation?.signing_address,
    request_nonce: (live.model_attestations || [])[0]?.request_nonce,
  },
  bundles: [],
};
for (const name of ['demo-receipt-bundle.json', 'testnet-receipt-bundle.json']) {
  const b = JSON.parse(readFileSync(`../fixtures/third_party_tee_receipts/${name}`, 'utf8'));
  const req = Buffer.from(b.request_b64, 'base64');
  const resp = Buffer.from(b.response_b64, 'base64');
  const expectedText = `${b.model}:${sha256hex(req)}:${sha256hex(resp)}`;
  const recovered = recoverAddress(b.signature.text, b.signature.signature);
  let parsedReq = null, parsedResp = null;
  try { parsedReq = JSON.parse(req.toString('utf8')); } catch {}
  try { parsedResp = JSON.parse(resp.toString('utf8')); } catch {}
  out.bundles.push({
    name,
    model: b.model,
    signature_kind: b.signature.signature_kind,
    request_bytes: req.length,
    response_bytes: resp.length,
    request_hash_matches_bytes: sha256hex(req) === b.request_hash,
    response_hash_matches_bytes: sha256hex(resp) === b.response_hash,
    signed_text_matches_bytes: expectedText === b.signature.text,
    recovered_address: recovered,
    recovered_equals_claimed_signer: recovered === b.signature.signing_address.toLowerCase(),
    signer_listed_in_live_attestation_2026_11_14: liveModelSigners.includes(recovered),
    request_model_field: parsedReq?.model ?? null,
    request_stream_field: parsedReq?.stream ?? null,
    response_id_equals_chat_id: parsedResp?.id === b.chat_id,
    response_finish_reason: parsedResp?.choices?.[0]?.finish_reason ?? null,
    created_at: b.created_at,
  });
}
writeFileSync('../results/00_fixture_check.json', JSON.stringify(out, null, 1));
console.log(JSON.stringify(out, null, 1));

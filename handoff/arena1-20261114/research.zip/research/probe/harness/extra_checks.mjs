// Two checks the main probe does not cover. Run from probe/harness: node extra_checks.mjs
//  X1  a receipt signed by a signer whose registration has expired is refused
//  X2  a signer registered for one model cannot satisfy a job for another model, even with a
//      correctly signed text for that other model (simulated signer)
import pkg from 'near-workspaces';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash, randomBytes } from 'node:crypto';
import { secp256k1 } from '@noble/curves/secp256k1';
import { keccak_256 } from '@noble/hashes/sha3';
const { Worker, parseNEAR } = pkg;
const N = (s) => parseNEAR(s).toString();
const sha256hex = (b) => createHash('sha256').update(b).digest('hex');
const A = JSON.parse(readFileSync('../fixtures/third_party_tee_receipts/demo-receipt-bundle.json', 'utf8'));
const eip191 = (t) => { const m = Buffer.from(t, 'utf8'); return keccak_256(Buffer.concat([Buffer.from(`\x19Ethereum Signed Message:\n${m.length}`), m])); };
const worker = await Worker.init();
const out = { generated_at: new Date().toISOString(), checks: [] };
try {
  const root = worker.rootAccount;
  const d = await root.createSubAccount('delegator', { initialBalance: N('50') });
  const w = await root.createSubAccount('worker', { initialBalance: N('50') });
  const deploy = () => root.devDeploy('../artifacts/receipt_escrow_probe.wasm', { initialBalance: N('30'), method: 'new', args: { owner: root.accountId } });
  const open = async (c, model, reqHash) => d.call(c, 'open', { policy: 'EagerHashOnly', worker: w.accountId, model_id: model, request_hash: reqHash, deadline_blocks: 40, window_blocks: 20, kill_fee: N('0.005') }, { attachedDeposit: N('0.055') });

  // X1: real receipt, registration already expired (expiry set to 1 ms after the epoch)
  let c = await deploy();
  await root.call(c, 'register_signer', { signing_address: A.signature.signing_address, model_id: A.model, attestation_sha256: '00'.repeat(32), expires_at_ms: 1 });
  let job = await open(c, A.model, A.request_hash);
  let r = await w.call(c, 'deliver', { job_id: job, response_hash: A.response_hash, signature: A.signature.signature, response_bytes: null });
  out.checks.push({ id: 'X1', what: 'real receipt, signer registration expired', evidence: 'real NEAR AI receipt (third-party recording)', accepted: r.accepted, reason: r.reason, pass: r.accepted === false && r.reason === 'signer_registration_expired' });

  // X2: local key registered for model "sim/a" signs a correct text for model "sim/b"
  c = await deploy();
  const sk = randomBytes(32);
  const pub = secp256k1.getPublicKey(sk, false).subarray(1);
  const addr = '0x' + Buffer.from(keccak_256(pub).subarray(12)).toString('hex');
  await root.call(c, 'register_signer', { signing_address: addr, model_id: 'sim/a', attestation_sha256: '00'.repeat(32), expires_at_ms: 4102444800000 });
  const reqHash = sha256hex(Buffer.from('{"model":"sim/b","messages":[{"role":"user","content":"x"}],"stream":false}'));
  const respHash = sha256hex(Buffer.from('response'));
  const sig = secp256k1.sign(eip191(`sim/b:${reqHash}:${respHash}`), sk, { lowS: true });
  const sigHex = '0x' + Buffer.from(sig.toCompactRawBytes()).toString('hex') + (27 + sig.recovery).toString(16).padStart(2, '0');
  job = await open(c, 'sim/b', reqHash);
  r = await w.call(c, 'deliver', { job_id: job, response_hash: respHash, signature: sigHex, response_bytes: null });
  out.checks.push({ id: 'X2', what: 'signer registered for another model signs the right text', evidence: 'SIMULATED signer (local key, not a TEE)', accepted: r.accepted, reason: r.reason, pass: r.accepted === false && r.reason === 'signer_registered_for_other_model' });
} finally { await worker.tearDown(); }
writeFileSync('../results/05_extra_checks.json', JSON.stringify(out, null, 1));
console.log(JSON.stringify(out, null, 1));

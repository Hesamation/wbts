import pkg from 'near-workspaces';
import { readFileSync } from 'node:fs';
const { Worker, parseNEAR } = pkg;
const N = (s) => parseNEAR(s).toString();
const t0 = Date.now();
const worker = await Worker.init();
try {
  const root = worker.rootAccount;
  console.log('sandbox up in', Date.now() - t0, 'ms; root', root.accountId);
  const c = await root.devDeploy('../artifacts/receipt_escrow_probe.wasm', { initialBalance: N('100'), method: 'new', args: { owner: root.accountId } });
  console.log('deployed', c.accountId);
  const b = JSON.parse(readFileSync('../fixtures/third_party_tee_receipts/demo-receipt-bundle.json', 'utf8'));
  const args = { model_id: b.model, request_hash: b.request_hash, response_hash: b.response_hash, signature: b.signature.signature };
  console.log('before register:', await c.view('check_receipt_view', args));
  await root.call(c, 'register_signer', { signing_address: b.signature.signing_address, model_id: b.model, attestation_sha256: '00'.repeat(32), expires_at_ms: 4102444800000 });
  console.log('after register :', await c.view('check_receipt_view', args));
  console.log('wrong model    :', await c.view('check_receipt_view', { ...args, model_id: 'z-ai/glm-5.3-flash' }));
  console.log('template ok    :', await c.view('check_request_view', { request_bytes: b.request_b64, model_id: b.model }));
  const st = await worker.provider.status();
  console.log('node version', JSON.stringify(st.version), 'protocol', st.protocol_version, 'height', st.sync_info.latest_block_height);
} finally {
  await worker.tearDown();
}

// Paired probe: the SAME attested-inference job, the SAME evaluator, six settlement policies.
//
// Runs on a local NEAR sandbox (nearcore 2.14.0, protocol 88). No keys, no testnet/mainnet
// accounts, no spend. Real evidence: two NEAR AI Cloud `provider_tee` receipts recorded by a
// third party (fixtures/third_party_tee_receipts/PROVENANCE.md). Cases that need a fresh signature
// use a locally generated key and are labelled `simulated signer`.
//
// Run from probe/harness:  node run_probe.mjs
// Output: ../results/02_paired_probe.json and ../results/02_paired_probe.md
import pkg from 'near-workspaces';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash, randomBytes } from 'node:crypto';
import { secp256k1 } from '@noble/curves/secp256k1';
import { keccak_256 } from '@noble/hashes/sha3';

const { Worker, parseNEAR } = pkg;
const N = (s) => parseNEAR(s).toString();
const WASM = '../artifacts/receipt_escrow_probe.wasm';
const sha256hex = (b) => createHash('sha256').update(b).digest('hex');
const b64 = (b) => Buffer.from(b).toString('base64');
const fmt = (y) => {
  const v = BigInt(y);
  const neg = v < 0n;
  const a = neg ? -v : v;
  const s = (Number(a / 10n ** 18n) / 1e6).toFixed(4);
  return (neg ? '-' : '') + s;
};

// ---------- evidence ----------
const load = (n) => JSON.parse(readFileSync(`../fixtures/third_party_tee_receipts/${n}`, 'utf8'));
const A = load('demo-receipt-bundle.json');
const B = load('testnet-receipt-bundle.json');
const A_REQ = Buffer.from(A.request_b64, 'base64');
const A_RESP = Buffer.from(A.response_b64, 'base64');
const MODEL = A.model;
const REAL_SIGNER = A.signature.signing_address;
const ATTESTATION_SHA = sha256hex(readFileSync('../live/attestation_qwen38_ecdsa.json'));

// Seeded inputs (labelled). Derived from the real request by a one-token edit.
const BAD_REQ_STREAM = Buffer.from(A_REQ.toString('utf8').replace('"stream":false', '"stream":true'), 'utf8');
if (BAD_REQ_STREAM.equals(A_REQ)) throw new Error('seed edit failed (stream)');
const OTHER_MODEL = 'z-ai/glm-5.3-flash';
const GLM_REQ = Buffer.from(A_REQ.toString('utf8').replace(`"model":"${MODEL}"`, `"model":"${OTHER_MODEL}"`), 'utf8');
if (GLM_REQ.equals(A_REQ)) throw new Error('seed edit failed (model)');
const TAMPERED_RESP = Buffer.from(A_RESP);
TAMPERED_RESP[TAMPERED_RESP.length - 20] ^= 0x01;

// Simulated signer (NOT a TEE): a local secp256k1 key signing in the NEAR AI text format.
const SIM_SK = randomBytes(32);
const SIM_MODEL = 'sim/local-key-model';
const eip191 = (text) => {
  const m = Buffer.from(text, 'utf8');
  return keccak_256(Buffer.concat([Buffer.from(`\x19Ethereum Signed Message:\n${m.length}`, 'utf8'), m]));
};
const simAddress = () => {
  const pub = secp256k1.getPublicKey(SIM_SK, false).subarray(1);
  return '0x' + Buffer.from(keccak_256(pub).subarray(12)).toString('hex');
};
const simSign = (model, reqHash, respHash) => {
  const sig = secp256k1.sign(eip191(`${model}:${reqHash}:${respHash}`), SIM_SK, { lowS: true });
  return '0x' + Buffer.from(sig.toCompactRawBytes()).toString('hex') + (27 + sig.recovery).toString(16).padStart(2, '0');
};

// ---------- parameters ----------
const PRICE = BigInt(N('0.05'));
const KILL = BigInt(N('0.005'));
const DA_BOND = BigInt(N('0.005'));
const ONE = BigInt(N('1'));
const QUARTER = BigInt(N('0.25'));
const DEADLINE = 40;
const WINDOW = 20;
const FAR_FUTURE_MS = 4102444800000; // 2100-01-01

// Every step marked "must fail" has to fail for THIS reason, not merely fail.
const EXPECT = {
  'too early: must fail': /^(window still open|deadline not reached)$/,
  'not available under this policy: must fail': /^policy has no input-fault path$/,
  'other bytes than the committed ones: must fail': /^these are not the committed request bytes$/,
  'one block too late: must fail': /^defense window closed$/,
  'wrong bytes: must fail': /^bytes do not hash to the delivered response_hash$/,
  'no such recourse under this policy: must fail': /^nothing to challenge$/,
  'no bytes: must fail': /^EagerPublic requires response_bytes$/,
};

const worker = await Worker.init();
const root = worker.rootAccount;
const height = async () => (await worker.provider.block({ finality: 'optimistic' })).header.height;
const ff = async (n) => { await worker.provider.fastForward(n); };

const deleg = await root.createSubAccount('delegator', { initialBalance: N('400') });
const wrk = await root.createSubAccount('worker', { initialBalance: N('400') });
const watcher = await root.createSubAccount('watcher', { initialBalance: N('400') });
const PARTIES = { delegator: deleg, worker: wrk, watcher };

async function deploy() {
  const c = await root.devDeploy(WASM, { initialBalance: N('30'), method: 'new', args: { owner: root.accountId } });
  await root.call(c, 'register_signer', { signing_address: REAL_SIGNER, model_id: MODEL, attestation_sha256: ATTESTATION_SHA, expires_at_ms: FAR_FUTURE_MS });
  await root.call(c, 'register_signer', { signing_address: simAddress(), model_id: SIM_MODEL, attestation_sha256: '00'.repeat(32), expires_at_ms: FAR_FUTURE_MS });
  return c;
}

class Run {
  constructor(c, kase, policy, label, evidence) {
    Object.assign(this, { c, kase, policy, label, evidence, steps: [], deposits: { delegator: 0n, worker: 0n, watcher: 0n }, openBlock: null, settleBlock: null });
  }
  async call(who, method, args = {}, deposit = 0n, note = '') {
    const acct = PARTIES[who];
    const r = await acct.callRaw(this.c, method, args, { attachedDeposit: deposit.toString(), gas: '300000000000000' });
    const fo = r.result;
    let gas = BigInt(fo.transaction_outcome.outcome.gas_burnt);
    for (const ro of fo.receipts_outcome) gas += BigInt(ro.outcome.gas_burnt);
    const ok = r.succeeded;
    let value = null;
    if (ok) { try { value = r.parseResult(); } catch { value = null; } }
    let error = null;
    if (!ok) {
      const all = JSON.stringify([fo.status, ...fo.receipts_outcome.map((x) => x.outcome.status)]);
      const m = /"ExecutionError":"((?:[^"\\]|\\.)*)"/.exec(all);
      error = m ? m[1].replace(/^Smart contract panicked: /, '') : all.slice(0, 300);
    }
    if (ok) this.deposits[who] += BigInt(deposit);
    const block = await height();
    const step = { by: who, method, ok, tgas: Number(gas) / 1e12, args_bytes: Buffer.byteLength(JSON.stringify(args)), deposit_near: fmt(deposit), block, note };
    if (value && typeof value === 'object' && 'reason' in value) Object.assign(step, { accepted: value.accepted, status: value.status, fault: value.fault, reason: value.reason });
    else if (value !== null && value !== undefined && value !== '') step.value = value;
    if (error) step.error = error;
    if (note.includes('must fail')) {
      step.expected_failure = true;
      step.failed_as_expected = !ok && EXPECT[note].test(error || '');
    }
    this.steps.push(step);
    if (method === 'open' && ok) { this.openBlock = block; this.job = value; }
    if (step.status === 'Settled') this.settleBlock = block;
    return step;
  }
  async open(model, reqHash, kill = 0n, attach = null) {
    const isW = this.policy === 'OptimisticAllegation' || this.policy === 'CheckedAllegation';
    const deposit = attach ?? (isW ? ONE : PRICE + kill);
    this.storageBefore = BigInt((await this.c.accountView()).storage_usage);
    return this.call('delegator', 'open', { policy: this.policy, worker: wrk.accountId, model_id: model, request_hash: reqHash, deadline_blocks: DEADLINE, window_blocks: WINDOW, kill_fee: kill.toString() }, deposit);
  }
  async finish() {
    const job = await this.c.view('get_job', { job_id: this.job });
    const credits = {}, net = {}, stats = {};
    for (const [k, a] of Object.entries(PARTIES)) {
      credits[k] = BigInt(await this.c.view('credit_of', { account: a.accountId }));
      net[k] = credits[k] - this.deposits[k];
      stats[k] = await this.c.view('stats_of', { account: a.accountId });
    }
    const storageAfter = BigInt((await this.c.accountView()).storage_usage);
    const auditBefore = await this.c.view('audit', {});
    // Capital exit: every party with a credit withdraws to its own account.
    const exits = {};
    for (const [k, a] of Object.entries(PARTIES)) {
      if (credits[k] === 0n) continue;
      const bal0 = BigInt((await a.balance()).total.toString());
      const r = await a.callRaw(this.c, 'withdraw', {}, { gas: '100000000000000' });
      const bal1 = BigInt((await a.balance()).total.toString());
      exits[k] = { ok: r.succeeded, wallet_delta_near: fmt(bal1 - bal0), credit_near: fmt(credits[k]) };
    }
    const audit = await this.c.view('audit', {});
    const nonzero = (s) => Object.fromEntries(Object.entries(s).filter(([, v]) => v !== 0));
    return {
      case: this.kase, policy: this.policy, label: this.label, evidence: this.evidence,
      final: { status: job.status, fault: job.fault, reason: job.reason, payload_bytes_onchain: job.payload_bytes_onchain },
      net_near: { delegator: fmt(net.delegator), worker: fmt(net.worker), watcher: fmt(net.watcher) },
      treasury_near: fmt(audit.treasury),
      stats: { delegator: nonzero(stats.delegator), worker: nonzero(stats.worker) },
      txs: this.steps.length,
      total_tgas: Number(this.steps.reduce((s, x) => s + x.tgas, 0).toFixed(3)),
      blocks_open_to_settle: this.settleBlock !== null && this.openBlock !== null ? this.settleBlock - this.openBlock : null,
      storage_delta_bytes: Number(storageAfter - this.storageBefore),
      funds_conserved_before_exit: auditBefore.conserved,
      funds_conserved_after_exit: audit.conserved,
      all_credits_withdrawn: audit.sum_credits === '0' && audit.locked === '0',
      exits,
      steps: this.steps,
    };
  }
}

const results = [];
async function scenario(kase, policy, label, evidence, fn) {
  const c = await deploy();
  const run = new Run(c, kase, policy, label, evidence);
  try {
    await fn(run);
    const rec = await run.finish();
    results.push(rec);
    console.log(`${kase.padEnd(4)} ${policy.padEnd(21)} ${String(rec.final.status).padEnd(9)} ${String(rec.final.fault).padEnd(22)} D=${rec.net_near.delegator} W=${rec.net_near.worker} tgas=${rec.total_tgas} blocks=${rec.blocks_open_to_settle} | ${label}`);
  } catch (e) {
    results.push({ case: kase, policy, label, evidence, harness_error: String(e && e.message ? e.message : e), steps: run.steps });
    console.log(`${kase} ${policy} HARNESS ERROR: ${e && e.message ? e.message : e}`);
  }
}

const REAL = 'real NEAR AI provider_tee receipt (third-party recording, 2026-11-01)';
const realDeliver = (withBytes) => ({ response_hash: A.response_hash, signature: A.signature.signature, response_bytes: withBytes ? b64(A_RESP) : null });
const ESCROWS = ['BinaryEscrow', 'EagerPublic', 'EagerHashOnly', 'RevealOnChallenge'];
const TYPED = ['EagerPublic', 'EagerHashOnly', 'RevealOnChallenge'];
const killFor = (p) => (p === 'BinaryEscrow' ? 0n : KILL);

// ===== C1 success control =====
for (const p of ESCROWS) {
  await scenario('C1', p, 'success control: valid receipt for the committed request', REAL, async (r) => {
    await r.open(MODEL, A.request_hash, killFor(p));
    await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(p === 'EagerPublic') });
    if (p === 'RevealOnChallenge') await r.call('delegator', 'ack', { job_id: r.job });
  });
}
await scenario('C1w', 'RevealOnChallenge', 'success, delegator never acks: paid when the window elapses', REAL, async (r) => {
  await r.open(MODEL, A.request_hash, KILL);
  await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) });
  await r.call('watcher', 'finalize', { job_id: r.job }, 0n, 'too early: must fail');
  await ff(WINDOW + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});
for (const p of ['OptimisticAllegation', 'CheckedAllegation']) {
  await scenario('C1', p, 'success control: completion anchored, no claim, collateral released after the filing window', REAL, async (r) => {
    await r.open(MODEL, A.request_hash);
    await r.call('worker', 'accept', { job_id: r.job }, ONE);
    await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) });
    await ff(WINDOW + 1);
    await r.call('watcher', 'finalize', { job_id: r.job });
  });
}

// ===== C2 invalid input (delegator fault) =====
const SEED_STREAM = 'SEEDED input: the real request with "stream":false flipped to true (gateway-signed by default, so no provider_tee receipt can exist)';
await scenario('C2', 'BinaryEscrow', 'invalid input: worker has no path, job expires', SEED_STREAM, async (r) => {
  await r.open(MODEL, sha256hex(BAD_REQ_STREAM));
  await r.call('worker', 'claim_invalid_input', { job_id: r.job, request_bytes: b64(BAD_REQ_STREAM) }, 0n, 'not available under this policy: must fail');
  await ff(DEADLINE + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});
for (const p of TYPED) {
  await scenario('C2', p, 'invalid input: worker reveals the committed bytes, evaluated at filing', SEED_STREAM, async (r) => {
    await r.open(MODEL, sha256hex(BAD_REQ_STREAM), KILL);
    await r.call('worker', 'claim_invalid_input', { job_id: r.job, request_bytes: b64(A_REQ) }, 0n, 'other bytes than the committed ones: must fail');
    await r.call('worker', 'claim_invalid_input', { job_id: r.job, request_bytes: b64(BAD_REQ_STREAM) });
  });
}

// ===== C3 invalid output (worker fault) =====
const tampered = (withBytes) => ({ response_hash: sha256hex(TAMPERED_RESP), signature: A.signature.signature, response_bytes: withBytes ? b64(TAMPERED_RESP) : null });
for (const p of ESCROWS) {
  await scenario('C3a', p, 'tampered response: one bit flipped, real signature attached', 'real signature + SEEDED tampered bytes', async (r) => {
    await r.open(MODEL, A.request_hash, killFor(p));
    await r.call('worker', 'deliver', { job_id: r.job, ...tampered(p === 'EagerPublic') });
    await ff(DEADLINE + 1);
    await r.call('watcher', 'finalize', { job_id: r.job });
  });
}
await scenario('C3a', 'OptimisticAllegation', 'tampered response, TRUE allegation, unchallenged: settles as filed (evaluator never runs)', 'real signature + SEEDED tampered bytes', async (r) => {
  await r.open(MODEL, A.request_hash);
  await r.call('worker', 'accept', { job_id: r.job }, ONE);
  await r.call('worker', 'deliver', { job_id: r.job, ...tampered(false) });
  await r.call('delegator', 'allege', { job_id: r.job }, QUARTER);
  await ff(WINDOW + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});
await scenario('C3a', 'CheckedAllegation', 'tampered response, TRUE allegation: evaluated and settled in the filing transaction', 'real signature + SEEDED tampered bytes', async (r) => {
  await r.open(MODEL, A.request_hash);
  await r.call('worker', 'accept', { job_id: r.job }, ONE);
  await r.call('worker', 'deliver', { job_id: r.job, ...tampered(false) });
  await r.call('delegator', 'allege', { job_id: r.job }, QUARTER);
});
await scenario('C3b', 'RevealOnChallenge', `model substitution: job requires ${OTHER_MODEL}, worker delivers a real receipt from ${MODEL}`, 'real receipt + SEEDED job terms', async (r) => {
  await r.open(OTHER_MODEL, sha256hex(GLM_REQ), KILL);
  await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) });
  await ff(DEADLINE + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});
await scenario('C3c', 'RevealOnChallenge', 'replay: a real receipt for a DIFFERENT request is delivered', 'second real receipt (third-party recording)', async (r) => {
  await r.open(MODEL, A.request_hash, KILL);
  await r.call('worker', 'deliver', { job_id: r.job, response_hash: B.response_hash, signature: B.signature.signature, response_bytes: null });
  await ff(DEADLINE + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});
await scenario('C3d', 'EagerHashOnly', 'reuse: the same real receipt is presented for a second job with the same request hash', REAL, async (r) => {
  await r.open(MODEL, A.request_hash, KILL);
  await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) });
  const first = r.job;
  await r.open(MODEL, A.request_hash, KILL);
  await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) }, 0n, `second job; job ${first} already consumed this receipt`);
  await ff(DEADLINE + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});
await scenario('C3e', 'RevealOnChallenge', 'forged signer: an unregistered local key signs the correct text', 'SIMULATED signer (local key, not a TEE)', async (r) => {
  await r.open(MODEL, A.request_hash, KILL);
  const sk = randomBytes(32);
  const sig = secp256k1.sign(eip191(`${MODEL}:${A.request_hash}:${A.response_hash}`), sk, { lowS: true });
  const sigHex = '0x' + Buffer.from(sig.toCompactRawBytes()).toString('hex') + (27 + sig.recovery).toString(16).padStart(2, '0');
  await r.call('worker', 'deliver', { job_id: r.job, response_hash: A.response_hash, signature: sigHex, response_bytes: null });
  await ff(DEADLINE + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});

// ===== C4 false allegation =====
for (const p of TYPED) {
  await scenario('C4a', p, 'worker falsely claims invalid input on a valid request; then delivers', REAL, async (r) => {
    await r.open(MODEL, A.request_hash, KILL);
    await r.call('worker', 'claim_invalid_input', { job_id: r.job, request_bytes: b64(A_REQ) });
    await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(p === 'EagerPublic') });
    if (p === 'RevealOnChallenge') await r.call('delegator', 'ack', { job_id: r.job });
  });
}
const wPrelude = async (r) => {
  await r.open(MODEL, A.request_hash);
  await r.call('worker', 'accept', { job_id: r.job }, ONE);
  await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) });
  await r.call('delegator', 'allege', { job_id: r.job }, QUARTER);
};
await scenario('C4b', 'OptimisticAllegation', 'delegator falsely blames a VALID real receipt; nobody challenges in the window', REAL, async (r) => {
  await wPrelude(r);
  await ff(WINDOW + 1);
  await r.call('watcher', 'challenge', { job_id: r.job }, QUARTER, 'one block too late: must fail');
  await r.call('delegator', 'finalize', { job_id: r.job });
});
await scenario('C4b', 'OptimisticAllegation', 'same false allegation; the accused worker challenges in time', REAL, async (r) => {
  await wPrelude(r);
  await r.call('worker', 'challenge', { job_id: r.job }, QUARTER);
});
await scenario('C4b', 'OptimisticAllegation', 'same false allegation; a third-party watcher challenges in time', REAL, async (r) => {
  await wPrelude(r);
  await r.call('watcher', 'challenge', { job_id: r.job }, QUARTER);
});
await scenario('C4b', 'CheckedAllegation', 'same false allegation; evaluated at filing and disproved', REAL, async (r) => {
  await wPrelude(r);
  await ff(WINDOW + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});
await scenario('C4c', 'RevealOnChallenge', 'delegator falsely claims the bytes were not delivered; worker reveals', REAL, async (r) => {
  await r.open(MODEL, A.request_hash, KILL);
  await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) });
  await r.call('delegator', 'claim_not_delivered', { job_id: r.job }, DA_BOND);
  await r.call('worker', 'reveal_response', { job_id: r.job, response_bytes: b64(TAMPERED_RESP) }, 0n, 'wrong bytes: must fail');
  await r.call('worker', 'reveal_response', { job_id: r.job, response_bytes: b64(A_RESP) });
});

// ===== C5 missing evidence =====
for (const p of [...ESCROWS, 'OptimisticAllegation']) {
  await scenario('C5a', p, 'worker never delivers anything', 'no evidence', async (r) => {
    await r.open(MODEL, A.request_hash, p === 'OptimisticAllegation' ? 0n : killFor(p));
    if (p === 'OptimisticAllegation') await r.call('worker', 'accept', { job_id: r.job }, ONE);
    await r.call('watcher', 'finalize', { job_id: r.job }, 0n, 'too early: must fail');
    await ff(DEADLINE + 1);
    await r.call('watcher', 'finalize', { job_id: r.job });
  });
}
for (const p of ['BinaryEscrow', 'EagerHashOnly']) {
  await scenario('C5b', p, 'valid receipt posted, response bytes withheld off-chain: delegator has no claim to file', REAL, async (r) => {
    await r.open(MODEL, A.request_hash, killFor(p));
    await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) });
    await r.call('delegator', 'claim_not_delivered', { job_id: r.job }, DA_BOND, 'no such recourse under this policy: must fail');
  });
}
await scenario('C5b', 'EagerPublic', 'withholding is impossible: delivery without the bytes is refused, job expires', REAL, async (r) => {
  await r.open(MODEL, A.request_hash, KILL);
  await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) }, 0n, 'no bytes: must fail');
  await ff(DEADLINE + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});
await scenario('C5b', 'RevealOnChallenge', 'valid receipt posted, bytes withheld: delegator challenges, worker stays silent', REAL, async (r) => {
  await r.open(MODEL, A.request_hash, KILL);
  await r.call('worker', 'deliver', { job_id: r.job, ...realDeliver(false) });
  await r.call('delegator', 'claim_not_delivered', { job_id: r.job }, DA_BOND);
  await ff(WINDOW + 1);
  await r.call('watcher', 'finalize', { job_id: r.job });
});

// ===== S: size scaling at the handoff's 8 KiB payload bound (simulated signer) =====
const BIG_RESP = Buffer.alloc(8192, 0x61);
const bigReqObj = { model: SIM_MODEL, messages: [{ role: 'user', content: 'x'.repeat(8192 - 80) }], stream: false };
const BIG_REQ = Buffer.from(JSON.stringify(bigReqObj), 'utf8');
const bigBadReq = Buffer.from(JSON.stringify({ ...bigReqObj, stream: true }), 'utf8');
const SIM = 'SIMULATED signer (local key, not a TEE); sizes only';
for (const p of ['EagerPublic', 'EagerHashOnly']) {
  await scenario('S1', p, `success with an ${BIG_RESP.length}-byte response`, SIM, async (r) => {
    await r.open(SIM_MODEL, sha256hex(BIG_REQ), KILL);
    const rh = sha256hex(BIG_RESP);
    await r.call('worker', 'deliver', { job_id: r.job, response_hash: rh, signature: simSign(SIM_MODEL, sha256hex(BIG_REQ), rh), response_bytes: p === 'EagerPublic' ? b64(BIG_RESP) : null });
  });
}
await scenario('S2', 'RevealOnChallenge', `challenged delivery: worker reveals an ${BIG_RESP.length}-byte response`, SIM, async (r) => {
  await r.open(SIM_MODEL, sha256hex(BIG_REQ), KILL);
  const rh = sha256hex(BIG_RESP);
  await r.call('worker', 'deliver', { job_id: r.job, response_hash: rh, signature: simSign(SIM_MODEL, sha256hex(BIG_REQ), rh), response_bytes: null });
  await r.call('delegator', 'claim_not_delivered', { job_id: r.job }, DA_BOND);
  await r.call('worker', 'reveal_response', { job_id: r.job, response_bytes: b64(BIG_RESP) });
});
await scenario('S3', 'RevealOnChallenge', `invalid-input claim revealing a ${bigBadReq.length}-byte request`, SIM, async (r) => {
  await r.open(SIM_MODEL, sha256hex(bigBadReq), KILL);
  await r.call('worker', 'claim_invalid_input', { job_id: r.job, request_bytes: b64(bigBadReq) });
});

const status = await worker.provider.status();
const meta = {
  generated_at: new Date().toISOString(),
  node: status.version, protocol_version: status.protocol_version,
  wasm_sha256: sha256hex(readFileSync(WASM)), wasm_bytes: readFileSync(WASM).length,
  parameters: { price_near: fmt(PRICE), kill_fee_near: fmt(KILL), da_bond_near: fmt(DA_BOND), deadline_blocks: DEADLINE, window_blocks: WINDOW, w_collateral_near: '1.0000', w_bond_near: '0.2500' },
  real_signer: REAL_SIGNER, model: MODEL, attestation_report_sha256: ATTESTATION_SHA,
  fixture_sizes: { request_bytes: A_REQ.length, response_bytes: A_RESP.length },
  note: 'net_near = credits received from the contract minus deposits made into it, per party; gas is NOT included in net_near. tgas is gas burnt summed over the transaction and its receipts.',
};
await worker.tearDown();

writeFileSync('../results/02_paired_probe.json', JSON.stringify({ meta, results }, null, 1));

// ---------- markdown ----------
const rows = results.map((r) => r.harness_error
  ? `| ${r.case} | ${r.policy} | HARNESS ERROR: ${r.harness_error} | | | | | | | |`
  : `| ${r.case} | ${r.policy} | ${r.label} | ${r.final.fault} / ${r.final.reason} | ${r.net_near.delegator} | ${r.net_near.worker} | ${r.net_near.watcher} | ${r.txs} | ${r.total_tgas} | ${r.blocks_open_to_settle ?? '—'} | ${r.final.payload_bytes_onchain} | ${r.funds_conserved_after_exit && r.all_credits_withdrawn ? 'yes' : 'NO'} |`);
const md = [
  '# Paired probe results (generated)', '',
  `Generated ${meta.generated_at} on nearcore ${meta.node.version} (protocol ${meta.protocol_version}). Wasm sha256 \`${meta.wasm_sha256}\`.`,
  `Price ${meta.parameters.price_near} NEAR, kill fee ${meta.parameters.kill_fee_near}, reveal bond ${meta.parameters.da_bond_near}, deadline ${DEADLINE} blocks, window ${WINDOW} blocks. Allegation policies use the handoff defaults (1 NEAR collateral, 0.25 NEAR bonds).`,
  '', 'Net columns are credits minus deposits per party, in NEAR, gas excluded. "Exit ok" means every credit was withdrawn and the contract ledger balanced to zero.', '',
  '| Case | Policy | What happens | Verdict (fault / reason) | Delegator net | Worker net | Watcher net | Txs | Tgas | Blocks open→settled | Payload bytes on chain | Exit ok |',
  '| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |',
  ...rows, '',
].join('\n');
writeFileSync('../results/02_paired_probe.md', md);
const bad = results.filter((r) => r.harness_error || !r.funds_conserved_after_exit || !r.all_credits_withdrawn);
const allSteps = results.flatMap((r) => (r.steps || []).map((x) => ({ ...x, case: r.case, policy: r.policy })));
const expectedFail = allSteps.filter((x) => x.expected_failure);
const wrongReason = expectedFail.filter((x) => !x.failed_as_expected);
const unexpected = allSteps.filter((x) => !x.ok && !x.expected_failure);
const summary = {
  scenario_runs: results.length,
  runs_with_harness_error_or_ledger_imbalance: bad.length,
  transactions: allSteps.length,
  expected_failures: expectedFail.length,
  expected_failures_with_the_expected_reason: expectedFail.length - wrongReason.length,
  unexpected_failures: unexpected.map((x) => `${x.case}/${x.policy}/${x.method}: ${x.error}`),
};
const full = JSON.parse(readFileSync('../results/02_paired_probe.json', 'utf8'));
full.summary = summary;
writeFileSync('../results/02_paired_probe.json', JSON.stringify(full, null, 1));
console.log('\nSUMMARY ' + JSON.stringify(summary, null, 1));

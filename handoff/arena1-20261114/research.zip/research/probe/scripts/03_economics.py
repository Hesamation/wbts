"""Turn the measured probe gas, live protocol parameters and handoff parameters into the comparison
the handoff asks for (START-HERE.md §5, Objection 2):

  eager checking cost  >  extra normal-path overhead + monitoring + expected claims/disputes
                          + capital/delay + missed-wrong-outcome risk   ?

Inputs (all files are in this folder):
  results/02_paired_probe.json            measured on nearcore 2.14.0 sandbox, protocol 88 (this probe)
  live/protocol_config_mainnet.json       fetched 2026-11-14 from rpc.mainnet.fastnear.com
  live/gas_price_mainnet.json             same
  live/near_price_coingecko.json          fetched 2026-11-14 (USD conversion only; volatile)
  live/models.json                        NEAR AI Cloud public model list with prices, fetched 2026-11-14
Handoff numbers are quoted from uploads/START-HERE.md and are NOT re-measured here.

Run from probe/:  python3 scripts/03_economics.py     (one read-only mainnet RPC call for block time)
"""
import base64, json, statistics, urllib.request, datetime

R = json.load(open("results/02_paired_probe.json"))
PC = json.load(open("live/protocol_config_mainnet.json"))["result"]
GAS_PRICE = int(json.load(open("live/gas_price_mainnet.json"))["result"]["gas_price"])  # yocto per gas
USD = json.load(open("live/near_price_coingecko.json"))["near"]["usd"]
NEAR_PER_TGAS = GAS_PRICE * 10**12 / 10**24
tg = lambda t: {"tgas": round(t, 3), "near": round(t * NEAR_PER_TGAS, 7), "usd": round(t * NEAR_PER_TGAS * USD, 6)}

def steps(policy=None, method=None, reason=None, ok=True):
    out = []
    for r in R["results"]:
        if policy and r["policy"] != policy:
            continue
        for s in r.get("steps", []):
            if s["ok"] != ok or (method and s["method"] != method):
                continue
            if reason is not None and s.get("reason") != reason:
                continue
            out.append(s)
    return out

def med(policy, method, reason=None, small=True):
    xs = [s["tgas"] for s in steps(policy, method, reason) if (s["args_bytes"] < 2000) == small]
    return statistics.median(xs) if xs else None

def case(c, policy, label_contains=""):
    for r in R["results"]:
        if r["case"] == c and r["policy"] == policy and label_contains in r["label"]:
            return r
    raise KeyError((c, policy, label_contains))

out = {"generated_at": datetime.datetime.now(datetime.UTC).isoformat(),
       "prices": {"mainnet_gas_price_yocto_per_gas": GAS_PRICE, "near_per_tgas": NEAR_PER_TGAS, "near_usd_coingecko": USD,
                  "mainnet_protocol_version": PC["protocol_version"], "sandbox_protocol_version": R["meta"]["protocol_version"],
                  "storage_near_per_byte": int(PC["runtime_config"]["storage_amount_per_byte"]) / 1e24}}

# ---- 1. what one extra transaction costs vs what the evaluator costs ----
unchecked = med("OptimisticAllegation", "deliver", "completion_anchored_unchecked")
checked_window = med("RevealOnChallenge", "deliver", "receipt_valid_window_open")
cheapest_tx = min(s["tgas"] for r in R["results"] for s in r.get("steps", []) if s["ok"])
finalizes = [s["tgas"] for s in steps(method="finalize")]
out["evaluator_vs_transaction"] = {
    "deliver_storing_evidence_unchecked": tg(unchecked),
    "deliver_storing_evidence_and_verifying_receipt": tg(checked_window),
    "marginal_cost_of_receipt_check_incl_replay_guard": tg(checked_window - unchecked),
    "cheapest_successful_state_changing_tx_observed": tg(cheapest_tx),
    "finalize_tx_range": [tg(min(finalizes)), tg(max(finalizes))],
    "reading": "Any design that defers the check needs at least one later transaction (finalize/release). "
               "That transaction costs several times the check it deferred.",
}
tc = PC["runtime_config"]["transaction_costs"]; wc = PC["runtime_config"]["wasm_config"]["ext_costs"]
floor = (2 * tc["action_receipt_creation_config"]["execution"] + tc["action_creation_config"]["function_call_cost"]["execution"]
         + tc["action_creation_config"]["function_call_cost"]["send_not_sir"]) / 1e12
out["evaluator_vs_transaction"]["protocol_fixed_fees_per_function_call_tx_tgas"] = round(floor, 3)
out["evaluator_vs_transaction"]["host_costs_tgas"] = {k: round(wc[k] / 1e12, 4) for k in ("ecrecover_base", "ed25519_verify_base", "keccak256_base", "sha256_base", "storage_write_base", "storage_read_base")}
out["evaluator_vs_transaction"]["contract_loading_tgas_for_this_wasm"] = round((wc["contract_loading_base"] + wc["contract_loading_bytes"] * R["meta"]["wasm_bytes"]) / 1e12, 3)

# ---- 2. happy path, all policies ----
hp = {}
for pol in ("BinaryEscrow", "EagerHashOnly", "EagerPublic", "RevealOnChallenge", "OptimisticAllegation", "CheckedAllegation"):
    r = case("C1", pol)
    hp[pol] = {"txs": r["txs"], **tg(r["total_tgas"]), "blocks_open_to_settle": r["blocks_open_to_settle"],
               "payload_bytes_onchain": r["final"]["payload_bytes_onchain"], "storage_delta_bytes": r["storage_delta_bytes"]}
rw = case("C1w", "RevealOnChallenge")
ok_steps = [s for s in rw["steps"] if s["ok"]]
hp["RevealOnChallenge_no_ack"] = {"txs": len(ok_steps), **tg(sum(s["tgas"] for s in ok_steps)), "blocks_open_to_settle": rw["blocks_open_to_settle"], "payload_bytes_onchain": 0}
s1p, s1h = case("S1", "EagerPublic"), case("S1", "EagerHashOnly")
hp["EagerPublic_8KiB_simulated_signer"] = {"txs": s1p["txs"], **tg(s1p["total_tgas"]), "payload_bytes_onchain": s1p["final"]["payload_bytes_onchain"]}
hp["EagerHashOnly_8KiB_simulated_signer"] = {"txs": s1h["txs"], **tg(s1h["total_tgas"]), "payload_bytes_onchain": 0}
out["happy_path"] = hp
c1p = case("C1", "EagerPublic")
per_kib = (s1p["total_tgas"] - c1p["total_tgas"]) / ((8192 - 900) / 1024)
base_pub = c1p["total_tgas"] - per_kib * 900 / 1024
out["publish_vs_reveal"] = {
    "eager_public_tgas_per_KiB_of_response": round(per_kib, 3),
    "reveal_on_challenge_happy_path_tgas": hp["RevealOnChallenge"]["tgas"],
    "response_size_KiB_where_always_publishing_costs_the_same_gas": round((hp["RevealOnChallenge"]["tgas"] - base_pub) / per_kib, 1),
    "reading": "Below that size, always publishing the response is CHEAPER in gas and settles at once. "
               "Reveal-on-challenge is not a gas optimisation at these sizes; its benefit is that no payload is published unless challenged.",
}

# ---- 3. dispute paths ----
c4c, s2, c5b = case("C4c", "RevealOnChallenge"), case("S2", "RevealOnChallenge"), case("C5b", "RevealOnChallenge")
okc = lambda r: sum(s["tgas"] for s in r["steps"] if s["ok"])
out["dispute_paths"] = {
    "reveal_on_challenge_false_not_delivered_900B": {**tg(okc(c4c)), "blocks": c4c["blocks_open_to_settle"], "net": c4c["net_near"]},
    "reveal_on_challenge_false_not_delivered_8KiB_simulated": {**tg(okc(s2)), "net": s2["net_near"]},
    "reveal_on_challenge_bytes_withheld": {**tg(okc(c5b)), "blocks": c5b["blocks_open_to_settle"], "net": c5b["net_near"]},
    "eager_hash_only_bytes_withheld": {"net": case("C5b", "EagerHashOnly")["net_near"], "recourse": "none"},
}

# ---- 4. the original optimistic policy on the same real evidence ----
w_un = case("C4b", "OptimisticAllegation", "nobody challenges")
w_wk = case("C4b", "OptimisticAllegation", "accused worker")
w_wt = case("C4b", "OptimisticAllegation", "watcher")
w_ck = case("C4b", "CheckedAllegation")
gain, loss = 0.20, 0.25
out["false_allegation"] = {
    "optimistic_unchallenged": {"net": w_un["net_near"], "verdict": w_un["final"], "blocks": w_un["blocks_open_to_settle"]},
    "optimistic_challenged_by_worker": {"net": w_wk["net_near"], "verdict": w_wk["final"]},
    "optimistic_challenged_by_watcher": {"net": w_wt["net_near"], "verdict": w_wt["final"]},
    "checked_at_filing": {"net": w_ck["net_near"], "delegator_stats": w_ck["stats"]["delegator"],
                          "filing_tx": tg(med("CheckedAllegation", "allege", "allegation_disproved_at_filing"))},
    "handoff_break_even_challenge_probability": round(gain / (gain + loss), 4),
    "expected_false_reporter_payoff_near": {f"p={p}": round(gain * (1 - p) - loss * p, 4) for p in (0.0, 0.25, 4 / 9, 0.75, 1.0)},
    "reading": "Checked at filing, the same allegation costs its author one transaction and moves no money, with no window and no monitor.",
}

# ---- 5. capital and delay ----
def block_time():
    def rpc(method, params):
        req = urllib.request.Request("https://rpc.mainnet.fastnear.com", data=json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode(), headers={"Content-Type": "application/json"})
        return json.load(urllib.request.urlopen(req, timeout=25))["result"]
    a = rpc("block", {"finality": "final"})["header"]
    b = rpc("block", {"block_id": a["height"] - 5000})["header"]
    return (a["timestamp"] - b["timestamp"]) / 1e9 / (a["height"] - b["height"]), a["height"]
try:
    bt, h = block_time()
    out["mainnet_block_time"] = {"seconds_per_block_over_last_5000_heights": round(bt, 3), "at_height": h,
                                 "handoff_600_block_window_minutes": round(600 * bt / 60, 1), "demo_60_block_window_seconds": round(60 * bt, 0)}
except Exception as e:
    out["mainnet_block_time"] = {"error": str(e)}
out["capital"] = {
    "optimistic_handoff_defaults": "1 NEAR per role per edge for the whole edge, plus 0.25 NEAR per filing/challenge bond; price not escrowed",
    "optimistic_locked_near_normal_path": 2.0, "optimistic_locked_near_disputed": 2.5,
    "eager_or_reveal_locked_near": float(R["meta"]["parameters"]["price_near"]) + float(R["meta"]["parameters"]["kill_fee_near"]),
    "reveal_extra_bond_only_when_challenging_near": float(R["meta"]["parameters"]["da_bond_near"]),
}

# ---- 6. is per-call settlement proportionate to the price of a call? ----
models = {m["modelId"]: m for m in json.load(open("live/models.json"))["models"]}
def usd(model, tin, tout):
    m = models[model]; i, o = m["inputCostPerToken"], m["outputCostPerToken"]
    return tin * i["amount"] / 10 ** i["scale"] + tout * o["amount"] / 10 ** o["scale"]
settle = hp["EagerHashOnly"]["usd"]; settle_reveal = hp["RevealOnChallenge"]["usd"]
rows = []
for model in ("Qwen/Qwen3.8-27B", "z-ai/glm-5.3-flash", "z-ai/glm-5.3", "moonshotai/kimi-k3"):
    for tin, tout in ((70, 97), (4000, 1000), (40000, 4000)):
        c = usd(model, tin, tout)
        rows.append({"model": model, "tokens_in": tin, "tokens_out": tout, "inference_usd": round(c, 6),
                     "eager_settlement_as_multiple_of_inference": round(settle / c, 2),
                     "reveal_settlement_as_multiple_of_inference": round(settle_reveal / c, 2)})
out["per_call_proportion"] = {"eager_hash_only_settlement_usd": settle, "reveal_on_challenge_settlement_usd": settle_reveal, "rows": rows,
                              "reading": "Two-transaction settlement costs more than a small call on a cheap model. One job per call only makes sense for larger calls; small calls need one job covering a batch of receipts (not built or measured here)."}

# ---- 7. a valid receipt for a useless answer (real fixture) ----
b = json.load(open("fixtures/third_party_tee_receipts/testnet-receipt-bundle.json"))
resp = json.loads(base64.b64decode(b["response_b64"]))
ch = resp["choices"][0]
out["valid_receipt_useless_answer"] = {"fixture": "testnet-receipt-bundle.json", "finish_reason": ch.get("finish_reason"),
                                       "content": ch["message"].get("content"), "request_max_tokens": json.loads(base64.b64decode(b["request_b64"])).get("max_tokens"),
                                       "reading": "This real, validly signed response has no answer text: the token budget the requester set was used up. A receipt proves provenance, never usefulness."}

json.dump(out, open("results/03_economics.json", "w"), indent=1)
print(json.dumps(out, indent=1))

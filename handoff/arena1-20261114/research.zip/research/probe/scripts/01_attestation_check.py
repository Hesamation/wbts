"""Verify the Intel TDX quote and bindings of the attestation report this probe fetched on 2026-11-14.

Follows the helper published at https://docs.near.ai/cloud/verification/reference/quote-nonce-signer
(fetched 2026-11-14; copy in research/sources/nearai-docs/). Uses the saved report, so the only
network access is dcap-qvl fetching Intel collateral. No credentials.

Run from probe/:  .venv/bin/python scripts/01_attestation_check.py
NOT checked here: NVIDIA GPU evidence (NRAS), image/source provenance, measurement allowlists.
"""
import asyncio, hashlib, json, struct, sys, datetime
import dcap_qvl

def _json(v):
    return json.loads(v) if isinstance(v, str) else v

def _identity(report):
    ident = bytes.fromhex(report["signing_address"].removeprefix("0x"))
    if {"ecdsa": 20, "ed25519": 32}.get(report["signing_algo"]) != len(ident):
        raise ValueError("unsupported signing identity")
    return ident

def replay_rtmr3(event_log):
    rtmr3 = bytes(48)
    for ev in _json(event_log):
        if ev.get("imr") != 3:
            continue
        digest = hashlib.sha384(struct.pack("<I", ev["event_type"]) + b":" + ev["event"].encode() + b":"
                                + bytes.fromhex(ev.get("event_payload") or "")).digest()
        if ev.get("digest") and bytes.fromhex(ev["digest"]) != digest:
            raise ValueError(f"digest mismatch for event {ev['event']}")
        rtmr3 = hashlib.sha384(rtmr3 + digest).digest()
    return rtmr3

async def check(report, nonce_hex):
    res = {"signing_address": report["signing_address"], "signing_algo": report["signing_algo"]}
    verified = await dcap_qvl.get_collateral_and_verify(bytes.fromhex(report["intel_quote"]))
    res["quote_signature_chain_verified"] = True
    res["tcb_status"] = verified.status
    res["advisory_ids"] = list(verified.advisory_ids)
    q = json.loads(verified.to_json())["report"]["TD10"]
    res["debug_mode_off"] = not (bytes.fromhex(q["td_attributes"])[0] & 1)
    ident = _identity(report)
    fp = report.get("tls_cert_fingerprint")
    bound = hashlib.sha256(ident + bytes.fromhex(fp)).digest() if fp else ident.ljust(32, b"\0")
    res["report_data_binds_signer_and_my_nonce"] = bytes.fromhex(q["report_data"]) == bound + bytes.fromhex(nonce_hex)
    res["echoed_nonce_matches"] = report["request_nonce"].lower() == nonce_hex.lower()
    app_compose = _json(report["info"]["tcb_info"])["app_compose"]
    compose_hash = hashlib.sha256(app_compose.encode()).digest()
    res["mr_config_id_matches_app_compose"] = bytes.fromhex(q["mr_config_id"]) == b"\x01" + compose_hash + bytes(15)
    res["app_compose_sha256"] = compose_hash.hex()
    res["rtmr3_replay_matches"] = replay_rtmr3(report["event_log"]) == bytes.fromhex(q["rt_mr3"])
    res["mr_td"] = q.get("mr_td")
    return res

async def main():
    nonce = open("live/attestation_nonce.txt").read().strip().split("=", 1)[1]
    out = {"checked_at": datetime.datetime.now(datetime.UTC).isoformat(), "nonce": nonce,
           "dcap_qvl_version": getattr(dcap_qvl, "__version__", "0.7.1"), "reports": []}
    for algo in ("ecdsa", "ed25519"):
        path = f"live/attestation_qwen38_{algo}.json"
        body = json.load(open(path))
        out_file = {"file": path, "sha256": hashlib.sha256(open(path, "rb").read()).hexdigest(), "checks": []}
        targets = [("gateway", body["gateway_attestation"])] + [(f"model:{m.get('model_name')}", m) for m in (body.get("model_attestations") or [])]
        for label, rep in targets:
            try:
                r = await check(rep, nonce)
                r["label"] = label
            except Exception as e:  # report, do not hide
                r = {"label": label, "error": f"{type(e).__name__}: {e}"}
            out_file["checks"].append(r)
        out["reports"].append(out_file)
    json.dump(out, open("results/01_attestation_check.json", "w"), indent=1)
    print(json.dumps(out, indent=1))

asyncio.run(main())

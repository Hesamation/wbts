# Paired settlement probe

This folder holds everything executed for `REPORT.md`. It runs one attested-inference job through six settlement policies that all use the same evaluator, on a local NEAR sandbox. It uses no keys, creates no testnet or mainnet accounts, spends nothing and deploys nothing.

The contract here is research code written for this comparison. It is not the WBTS contract, it has not been audited, and it was tested only on the cases listed below.

## Run it

```sh
./reproduce.sh                 # build, check evidence, run all 42 scenario runs, compute costs (15-20 min)
SKIP_PROBE=1 ./reproduce.sh    # same, but keep the saved probe results (about 2 min)
REFRESH_LIVE=1 ./reproduce.sh  # also re-fetch the attestation report, gas price, model prices
```

Requirements: Linux x86_64, Node 20 or newer, Python 3.9 or newer, `curl`, a C linker. The script installs a Rust toolchain under `~/.local` if `cargo` is missing.

## What is here

| Path | What it is |
| --- | --- |
| `contract/src/lib.rs` | The probe contract: the evaluator plus six policies (see below). |
| `artifacts/receipt_escrow_probe.wasm` | The built contract, sha256 `095fdf89…57de3d`. The build reproduces byte for byte in this environment. |
| `fixtures/third_party_tee_receipts/` | Two recorded NEAR AI Cloud receipts (MIT, third party). Read `PROVENANCE.md`. |
| `live/` | Inputs fetched on 2026-11-14: attestation reports with this probe's nonce, mainnet protocol config and gas price, model prices, NEAR price, Agent Market listing. |
| `harness/00_fixture_check.mjs` | Checks the recorded receipts off-chain with independent code. |
| `scripts/01_attestation_check.py` | Verifies the Intel TDX quote and bindings of the live attestation report. |
| `harness/run_probe.mjs` | The paired probe. |
| `scripts/03_economics.py` | Turns measured gas and live prices into the cost comparison. |
| `harness/extra_checks.mjs` | Two cases outside the main matrix: expired signer registration, signer registered for another model. |
| `results/` | Outputs of the steps above, plus `04_market_snapshot.json`. Start with `02_paired_probe.md`. |

## The evaluator and the six policies

The evaluator has two parts. It accepts a delivery when a registered signer for the job's model signed the text `<model>:<sha256(request)>:<sha256(response)>` (the format of a NEAR AI Cloud `provider_tee` response signature), where the request hash is the one the delegator committed when opening the job. It rejects a committed request when its bytes are not a JSON object with the agreed `model`, with `stream` absent or `false`, and with a non-empty `messages` array.

| Policy in the code | What it stands for |
| --- | --- |
| `BinaryEscrow` | An escrow with the money outcomes of the ERC-8183 draft: completed pays the worker, expired refunds the delegator. No fault classes. |
| `EagerHashOnly` | A capable evaluator escrow: typed verdicts and a kill fee, delivery by hash and signature, paid at once. |
| `EagerPublic` | The same, but the response bytes must be in the delivery transaction. |
| `RevealOnChallenge` | The proposed design: everything decidable from commitments is checked at once; a window exists only so the delegator can demand the response bytes. |
| `OptimisticAllegation` | A model of the WBTS policy described in the handoff: an allegation is stored unevaluated, a bonded challenge runs the evaluator, an unchallenged allegation becomes final. Collateral and bonds use the handoff defaults. |
| `CheckedAllegation` | The handoff's "evaluate every filed claim" option on the same collateral. |

The two allegation policies are a re-implementation from the handoff's description. They are not measurements of the WBTS contract.

## Result summary

42 scenario runs, 143 transactions. Every run balanced its ledger and every credit was withdrawn. 15 steps were required to fail, and all 15 failed with the expected error text. No step failed unexpectedly. Details: `results/02_paired_probe.json` (`summary` key).

## Build notes

Three things went wrong before the contract ran correctly. Each matters for anyone adding this verifier to another contract without `cargo-near`.

1. `env::ecrecover` is behind the `unstable` feature in near-sdk 5.30.2. `env::ed25519_verify` is not.
2. Rust 1.100 emits WebAssembly features that nearcore 2.14.0 rejects (`PrepareError: Deserialization`). Building `std` with `-C target-cpu=mvp` fixes it.
3. near-sdk 5.30 calls host functions only when compiled with `--cfg near`. Without it the contract still deploys and the signature check still passes, but every panic becomes a bare `unreachable` trap with no message. The first full run of this probe had that defect; it was caught because the expected-failure steps had no error text. All results in `results/` are from the corrected build.

## What this probe does not show

- It does not show that anyone wants to buy a fully specified model call from another operator.
- It made no new NEAR AI call. The receipts are a third party's recordings from 2026-11-01. A per-job nonce inside the request was not tested against the live service.
- It does not verify NVIDIA GPU evidence or image provenance. Signer registration in the contract is owner-only.
- A valid receipt says which key signed which request and response hashes. It says nothing about whether the answer is good; `testnet-receipt-bundle.json` is a validly signed response with no answer text.

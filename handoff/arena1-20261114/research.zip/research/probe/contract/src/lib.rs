//! PROBE ONLY — unaudited research code, written for one paired comparison. Not the WBTS contract.
//!
//! One job, six settlement policies, ONE shared evaluator:
//!
//!   evaluator = (a) NEAR AI Cloud `provider_tee` response signature over
//!                   "<model_id>:<sha256(request)>:<sha256(response)>" (EIP-191, secp256k1),
//!                   recovered with `env::ecrecover` and matched to a registered signer; and
//!               (b) a request-template predicate on the exact request bytes the delegator committed.
//!
//! Policies (see REPORT.md for why each exists):
//!   BinaryEscrow          ERC-8183-shaped: complete -> worker, expire -> delegator. No fault classes.
//!   EagerPublic           capable evaluator-escrow, typed verdicts, response bytes always in calldata.
//!   EagerHashOnly         same, hash-only delivery, pays at once (no recourse for withheld bytes).
//!   RevealOnChallenge     proposed: eager for commitments; window only for payload claims.
//!   OptimisticAllegation  MODEL of the handoff's policy: evidence authenticated at filing, semantic
//!                         check only inside a bonded challenge; unchallenged allegations finalize.
//!   CheckedAllegation     the handoff's "evaluate every filed claim" option on the same collateral.
//!
//! Trust boundary: `register_signer` is owner-only. The contract checks a signature against a
//! registered address; it does NOT verify a TDX quote. Quote verification is done off-chain
//! (probe/scripts/01_attestation_check.py). A valid receipt proves provenance of a
//! (request, response) pair under that key. It says nothing about answer quality.

use near_sdk::json_types::{Base64VecU8, U128};
use near_sdk::store::{LookupMap, LookupSet};
use near_sdk::{env, near, require, AccountId, NearToken, PanicOnDefault, Promise};

const NEAR: u128 = 1_000_000_000_000_000_000_000_000;
// Handoff defaults (START-HERE.md §3). Used only by the two *Allegation policies.
const W_COLLATERAL: u128 = NEAR;
const W_BOND: u128 = NEAR / 4;
const W_RESERVATION: u128 = NEAR / 4;

#[near(serializers = [borsh, json])]
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Policy {
    BinaryEscrow,
    EagerPublic,
    EagerHashOnly,
    RevealOnChallenge,
    OptimisticAllegation,
    CheckedAllegation,
}

#[near(serializers = [borsh, json])]
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Status {
    Open,
    Delivered,
    Challenged,
    Alleged,
    Settled,
}

/// Fault ORIGIN found by the evaluator. Who pays what is decided separately, in `settle` callers.
#[near(serializers = [borsh, json])]
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Fault {
    /// Valid receipt for the committed request; nobody at fault.
    NoFault,
    /// The request the delegator committed fails the agreed template.
    DelegatorInput,
    /// Evaluated: the delivered receipt does not verify.
    WorkerReceipt,
    /// No acceptable receipt before the deadline.
    WorkerNoReceipt,
    /// Receipt verified, but the response bytes were not revealed when challenged.
    WorkerWithheld,
    /// The delegator's allegation was evaluated and disproved.
    FalseClaimByDelegator,
    /// NOT a finding: an allegation settled as filed, without the evaluator running.
    UncheckedBlameAccepted,
}

#[near(serializers = [borsh, json])]
#[derive(Clone)]
pub struct Signer {
    pub model_id: String,
    pub attestation_sha256: String,
    pub expires_at_ms: u64,
}

#[near(serializers = [borsh, json])]
#[derive(Clone)]
pub struct Job {
    pub policy: Policy,
    pub delegator: AccountId,
    pub worker: AccountId,
    pub model_id: String,
    pub request_hash: String,
    pub price: U128,
    pub kill_fee: U128,
    pub deadline_block: u64,
    pub window_blocks: u64,
    pub status: Status,
    pub response_hash: Option<String>,
    pub signature: Option<String>,
    pub window_end: u64,
    pub claimant: Option<AccountId>,
    pub claim_bond: U128,
    pub delegator_collateral: U128,
    pub worker_collateral: U128,
    pub held: U128,
    pub fault: Option<Fault>,
    pub reason: Option<String>,
    pub payload_bytes_onchain: u32,
}

#[near(serializers = [borsh, json])]
#[derive(Clone, Default)]
pub struct Stats {
    pub jobs_no_fault: u32,
    pub input_faults: u32,
    pub receipt_faults: u32,
    pub no_receipt: u32,
    pub withheld: u32,
    pub false_claims: u32,
    pub refused_deliveries: u32,
    pub blamed_unchecked: u32,
}

#[near(serializers = [json])]
pub struct Outcome {
    pub job_id: u64,
    pub accepted: bool,
    pub status: Status,
    pub fault: Option<Fault>,
    pub reason: String,
}

#[near(serializers = [json])]
pub struct Audit {
    pub total_in: U128,
    pub locked: U128,
    pub sum_credits: U128,
    pub treasury: U128,
    pub total_out: U128,
    pub conserved: bool,
}

#[near(contract_state)]
#[derive(PanicOnDefault)]
pub struct Probe {
    owner: AccountId,
    signers: LookupMap<[u8; 20], Signer>,
    jobs: LookupMap<u64, Job>,
    credits: LookupMap<AccountId, u128>,
    stats: LookupMap<AccountId, Stats>,
    used_receipts: LookupSet<[u8; 32]>,
    next_id: u64,
    total_in: u128,
    locked: u128,
    sum_credits: u128,
    treasury: u128,
    total_out: u128,
}

// ---------- pure helpers ----------

fn hex(bytes: &[u8]) -> String {
    const T: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push(T[(b >> 4) as usize] as char);
        s.push(T[(b & 15) as usize] as char);
    }
    s
}

fn unhex(s: &str) -> Option<Vec<u8>> {
    let s = s.strip_prefix("0x").unwrap_or(s).as_bytes();
    if s.len() % 2 != 0 {
        return None;
    }
    let nib = |c: u8| match c {
        b'0'..=b'9' => Some(c - b'0'),
        b'a'..=b'f' => Some(c - b'a' + 10),
        b'A'..=b'F' => Some(c - b'A' + 10),
        _ => None,
    };
    let mut out = Vec::with_capacity(s.len() / 2);
    for p in s.chunks(2) {
        out.push((nib(p[0])? << 4) | nib(p[1])?);
    }
    Some(out)
}

/// Normalise a 32-byte hash to lowercase hex, or panic.
fn norm_hash(s: &str) -> String {
    let b = unhex(s).unwrap_or_else(|| env::panic_str("hash must be hex"));
    require!(b.len() == 32, "hash must be 32 bytes");
    hex(&b)
}

/// The text NEAR AI Cloud's model TEE signs for a `provider_tee` signature.
fn signed_text(model_id: &str, request_hash: &str, response_hash: &str) -> String {
    format!("{model_id}:{request_hash}:{response_hash}")
}

/// EIP-191 personal_sign recovery -> 20-byte Ethereum address.
fn recover_address(text: &str, sig: &[u8]) -> Option<[u8; 20]> {
    if sig.len() != 65 {
        return None;
    }
    let prefix = format!("\x19Ethereum Signed Message:\n{}", text.len());
    let mut msg = Vec::with_capacity(prefix.len() + text.len());
    msg.extend_from_slice(prefix.as_bytes());
    msg.extend_from_slice(text.as_bytes());
    let hash = env::keccak256(&msg);
    let v = match sig[64] {
        27 | 28 => sig[64] - 27,
        0 | 1 => sig[64],
        _ => return None,
    };
    // malleability_flag = true rejects high-s signatures.
    let pk = env::ecrecover(&hash, &sig[..64], v, true)?;
    let h = env::keccak256(&pk);
    let mut a = [0u8; 20];
    a.copy_from_slice(&h[12..]);
    Some(a)
}

/// Request-template predicate. Deterministic, on the exact committed bytes.
/// Rules mirror what the NEAR AI docs say is needed for a `provider_tee` signature:
/// canonical model id in the body, and no streaming (streamed replies are gateway-signed by default).
fn check_request_template(bytes: &[u8], model_id: &str) -> Result<(), String> {
    let v: near_sdk::serde_json::Value =
        near_sdk::serde_json::from_slice(bytes).map_err(|_| "request_not_json".to_string())?;
    let o = v.as_object().ok_or_else(|| "request_not_object".to_string())?;
    match o.get("model").and_then(|m| m.as_str()) {
        Some(m) if m == model_id => {}
        _ => return Err("model_field_mismatch".to_string()),
    }
    if let Some(s) = o.get("stream") {
        if s.as_bool() != Some(false) {
            return Err("stream_not_false".to_string());
        }
    }
    match o.get("messages").and_then(|m| m.as_array()) {
        Some(a) if !a.is_empty() => Ok(()),
        _ => Err("messages_missing".to_string()),
    }
}

fn reward(slashed: u128) -> u128 {
    slashed * 4 / 5
}

#[near]
impl Probe {
    #[init]
    pub fn new(owner: AccountId) -> Self {
        Self {
            owner,
            signers: LookupMap::new(b"s"),
            jobs: LookupMap::new(b"j"),
            credits: LookupMap::new(b"c"),
            stats: LookupMap::new(b"t"),
            used_receipts: LookupSet::new(b"u"),
            next_id: 0,
            total_in: 0,
            locked: 0,
            sum_credits: 0,
            treasury: 0,
            total_out: 0,
        }
    }

    /// Owner-only trust anchor. The caller is expected to have verified the attestation report
    /// (TDX quote, nonce, signer binding) off-chain; only its hash is recorded here.
    pub fn register_signer(
        &mut self,
        signing_address: String,
        model_id: String,
        attestation_sha256: String,
        expires_at_ms: u64,
    ) {
        require!(env::predecessor_account_id() == self.owner, "only owner");
        let a = unhex(&signing_address).unwrap_or_else(|| env::panic_str("address must be hex"));
        require!(a.len() == 20, "address must be 20 bytes");
        let mut k = [0u8; 20];
        k.copy_from_slice(&a);
        self.signers.insert(
            k,
            Signer { model_id, attestation_sha256: norm_hash(&attestation_sha256), expires_at_ms },
        );
    }

    // ---------- evaluator ----------

    fn check_receipt(
        &self,
        model_id: &str,
        request_hash: &str,
        response_hash: &str,
        signature: &str,
    ) -> Result<[u8; 32], String> {
        let sig = unhex(signature).ok_or_else(|| "bad_signature_encoding".to_string())?;
        let text = signed_text(model_id, request_hash, response_hash);
        let addr = recover_address(&text, &sig).ok_or_else(|| "signature_unrecoverable".to_string())?;
        let signer = self
            .signers
            .get(&addr)
            .ok_or_else(|| format!("signer_not_registered:0x{}", hex(&addr)))?;
        if signer.model_id != model_id {
            return Err("signer_registered_for_other_model".to_string());
        }
        if env::block_timestamp_ms() >= signer.expires_at_ms {
            return Err("signer_registration_expired".to_string());
        }
        let mut id = [0u8; 32];
        id.copy_from_slice(&env::sha256(text.as_bytes()));
        if self.used_receipts.contains(&id) {
            return Err("receipt_already_used".to_string());
        }
        Ok(id)
    }

    /// View: "ok" or the refusal reason.
    pub fn check_receipt_view(
        &self,
        model_id: String,
        request_hash: String,
        response_hash: String,
        signature: String,
    ) -> String {
        match self.check_receipt(&model_id, &norm_hash(&request_hash), &norm_hash(&response_hash), &signature) {
            Ok(_) => "ok".to_string(),
            Err(e) => e,
        }
    }

    /// View: "ok" or the template violation.
    pub fn check_request_view(&self, request_bytes: Base64VecU8, model_id: String) -> String {
        match check_request_template(&request_bytes.0, &model_id) {
            Ok(()) => "ok".to_string(),
            Err(e) => e,
        }
    }

    // ---------- accounting ----------

    fn take(&mut self, job: &mut Job, amount: u128) {
        self.total_in += amount;
        self.locked += amount;
        job.held = U128(job.held.0 + amount);
    }

    fn credit(&mut self, who: &AccountId, amount: u128) {
        if amount == 0 {
            return;
        }
        let c = self.credits.get(who).copied().unwrap_or(0);
        self.credits.insert(who.clone(), c + amount);
        self.sum_credits += amount;
    }

    fn bump(&mut self, who: &AccountId, f: impl FnOnce(&mut Stats)) {
        let mut s = self.stats.get(who).cloned().unwrap_or_default();
        f(&mut s);
        self.stats.insert(who.clone(), s);
    }

    fn job(&self, id: u64) -> Job {
        self.jobs.get(&id).cloned().unwrap_or_else(|| env::panic_str("no such job"))
    }

    fn outcome(id: u64, accepted: bool, job: &Job, reason: &str) -> Outcome {
        Outcome { job_id: id, accepted, status: job.status, fault: job.fault, reason: reason.to_string() }
    }

    /// The only place money leaves a job. Payouts + treasury must equal everything held.
    fn settle(
        &mut self,
        id: u64,
        mut job: Job,
        fault: Fault,
        reason: &str,
        payouts: &[(AccountId, u128)],
        to_treasury: u128,
    ) -> Outcome {
        let total: u128 = payouts.iter().map(|p| p.1).sum::<u128>() + to_treasury;
        require!(total == job.held.0, "settlement does not conserve job funds");
        self.locked -= job.held.0;
        for (who, amount) in payouts {
            self.credit(who, *amount);
        }
        self.treasury += to_treasury;
        job.held = U128(0);
        job.status = Status::Settled;
        job.fault = Some(fault);
        job.reason = Some(reason.to_string());
        env::log_str(&format!(
            "FAULT_RECEIPT:{{\"job\":{},\"policy\":\"{:?}\",\"fault\":\"{:?}\",\"reason\":\"{}\",\"request_hash\":\"{}\",\"response_hash\":\"{}\",\"block\":{}}}",
            id,
            job.policy,
            fault,
            reason,
            job.request_hash,
            job.response_hash.clone().unwrap_or_default(),
            env::block_height()
        ));
        self.jobs.insert(id, job.clone());
        Self::outcome(id, true, &job, reason)
    }

    fn pay_success(&mut self, id: u64, job: Job, reason: &str) -> Outcome {
        let (d, w) = (job.delegator.clone(), job.worker.clone());
        self.bump(&w, |s| s.jobs_no_fault += 1);
        let pay = [
            (w, job.price.0 + job.worker_collateral.0),
            (d, job.kill_fee.0 + job.delegator_collateral.0),
        ];
        self.settle(id, job, Fault::NoFault, reason, &pay, 0)
    }

    // ---------- lifecycle ----------

    /// Delegator opens a job and commits sha256(request bytes) and the model id.
    /// Escrow policies: attach price + kill_fee. Allegation policies: attach 1 NEAR collateral.
    #[payable]
    pub fn open(
        &mut self,
        policy: Policy,
        worker: AccountId,
        model_id: String,
        request_hash: String,
        deadline_blocks: u64,
        window_blocks: u64,
        kill_fee: U128,
    ) -> u64 {
        let attached = env::attached_deposit().as_yoctonear();
        let is_w = matches!(policy, Policy::OptimisticAllegation | Policy::CheckedAllegation);
        let (price, kill, coll) = if is_w {
            require!(attached == W_COLLATERAL, "attach exactly 1 NEAR collateral");
            (0, 0, W_COLLATERAL)
        } else {
            if policy == Policy::BinaryEscrow {
                require!(kill_fee.0 == 0, "binary escrow has no kill fee");
            }
            require!(attached > kill_fee.0, "attach price + kill_fee");
            (attached - kill_fee.0, kill_fee.0, 0)
        };
        let id = self.next_id;
        self.next_id += 1;
        let mut job = Job {
            policy,
            delegator: env::predecessor_account_id(),
            worker,
            model_id,
            request_hash: norm_hash(&request_hash),
            price: U128(price),
            kill_fee: U128(kill),
            deadline_block: env::block_height() + deadline_blocks,
            window_blocks,
            status: Status::Open,
            response_hash: None,
            signature: None,
            window_end: 0,
            claimant: None,
            claim_bond: U128(0),
            delegator_collateral: U128(coll),
            worker_collateral: U128(0),
            held: U128(0),
            fault: None,
            reason: None,
            payload_bytes_onchain: 0,
        };
        self.take(&mut job, attached);
        self.jobs.insert(id, job);
        id
    }

    /// Allegation policies only: the worker funds its own collateral.
    #[payable]
    pub fn accept(&mut self, job_id: u64) {
        let mut job = self.job(job_id);
        require!(env::predecessor_account_id() == job.worker, "only the worker");
        require!(matches!(job.policy, Policy::OptimisticAllegation | Policy::CheckedAllegation), "no accept step");
        require!(job.status == Status::Open && job.worker_collateral.0 == 0, "already accepted");
        let attached = env::attached_deposit().as_yoctonear();
        require!(attached == W_COLLATERAL, "attach exactly 1 NEAR collateral");
        job.worker_collateral = U128(attached);
        self.take(&mut job, attached);
        self.jobs.insert(job_id, job);
    }

    /// Worker delivers (response_hash, signature). EagerPublic also requires the response bytes.
    pub fn deliver(
        &mut self,
        job_id: u64,
        response_hash: String,
        signature: String,
        response_bytes: Option<Base64VecU8>,
    ) -> Outcome {
        let mut job = self.job(job_id);
        require!(env::predecessor_account_id() == job.worker, "only the worker");
        require!(job.status == Status::Open, "job not open");
        require!(env::block_height() <= job.deadline_block, "deadline passed");
        let resp = norm_hash(&response_hash);

        if matches!(job.policy, Policy::OptimisticAllegation | Policy::CheckedAllegation) {
            require!(job.worker_collateral.0 > 0, "worker has not accepted");
            // Handoff policy: completion is anchored and evidence authenticated; no semantic check here.
            job.response_hash = Some(resp);
            job.signature = Some(signature);
            job.status = Status::Delivered;
            job.window_end = env::block_height() + job.window_blocks;
            self.jobs.insert(job_id, job.clone());
            return Self::outcome(job_id, true, &job, "completion_anchored_unchecked");
        }

        let mut published = 0u32;
        if job.policy == Policy::EagerPublic {
            let bytes = response_bytes
                .unwrap_or_else(|| env::panic_str("EagerPublic requires response_bytes"))
                .0;
            require!(hex(&env::sha256(&bytes)) == resp, "response_bytes do not hash to response_hash");
            published = bytes.len() as u32;
        }

        let receipt_id = match self.check_receipt(&job.model_id, &job.request_hash, &resp, &signature) {
            Ok(id) => id,
            Err(reason) => {
                // Refused. The job stays open so an honest worker can retry before the deadline.
                let w = job.worker.clone();
                self.bump(&w, |s| s.refused_deliveries += 1);
                return Self::outcome(job_id, false, &job, &reason);
            }
        };
        self.used_receipts.insert(receipt_id);
        job.response_hash = Some(resp);
        job.signature = Some(signature);
        job.payload_bytes_onchain += published;

        if job.policy == Policy::RevealOnChallenge {
            job.status = Status::Delivered;
            job.window_end = env::block_height() + job.window_blocks;
            self.jobs.insert(job_id, job.clone());
            return Self::outcome(job_id, true, &job, "receipt_valid_window_open");
        }
        self.pay_success(job_id, job, "receipt_valid")
    }

    /// RevealOnChallenge: the delegator confirms it holds the bytes; pays the worker at once.
    pub fn ack(&mut self, job_id: u64) -> Outcome {
        let job = self.job(job_id);
        require!(env::predecessor_account_id() == job.delegator, "only the delegator");
        require!(job.policy == Policy::RevealOnChallenge && job.status == Status::Delivered, "nothing to ack");
        self.pay_success(job_id, job, "receipt_valid_acknowledged")
    }

    /// Worker claims the committed request is invalid, by revealing the exact committed bytes.
    /// Evaluated at filing. Not available under BinaryEscrow (that is the point of the comparison).
    pub fn claim_invalid_input(&mut self, job_id: u64, request_bytes: Base64VecU8) -> Outcome {
        let mut job = self.job(job_id);
        require!(env::predecessor_account_id() == job.worker, "only the worker");
        require!(
            matches!(job.policy, Policy::EagerPublic | Policy::EagerHashOnly | Policy::RevealOnChallenge),
            "policy has no input-fault path"
        );
        require!(job.status == Status::Open, "job not open");
        require!(env::block_height() <= job.deadline_block, "deadline passed");
        require!(
            hex(&env::sha256(&request_bytes.0)) == job.request_hash,
            "these are not the committed request bytes"
        );
        job.payload_bytes_onchain += request_bytes.0.len() as u32;
        match check_request_template(&request_bytes.0, &job.model_id) {
            Err(reason) => {
                let (d, w) = (job.delegator.clone(), job.worker.clone());
                self.bump(&d, |s| s.input_faults += 1);
                let pay = [(w, job.kill_fee.0), (d, job.price.0)];
                self.settle(job_id, job, Fault::DelegatorInput, &reason, &pay, 0)
            }
            Ok(()) => {
                let w = job.worker.clone();
                self.bump(&w, |s| s.false_claims += 1);
                self.jobs.insert(job_id, job.clone());
                Self::outcome(job_id, false, &job, "input_is_valid_claim_rejected")
            }
        }
    }

    /// RevealOnChallenge: the delegator says it never received the response bytes. Bonded.
    #[payable]
    pub fn claim_not_delivered(&mut self, job_id: u64) -> Outcome {
        let mut job = self.job(job_id);
        require!(env::predecessor_account_id() == job.delegator, "only the delegator");
        require!(job.policy == Policy::RevealOnChallenge && job.status == Status::Delivered, "nothing to challenge");
        require!(env::block_height() <= job.window_end, "window closed");
        let bond = env::attached_deposit().as_yoctonear();
        require!(bond >= job.price.0 / 10 && bond > 0, "bond must be at least 10% of the price");
        job.claim_bond = U128(bond);
        job.claimant = Some(job.delegator.clone());
        self.take(&mut job, bond);
        job.status = Status::Challenged;
        job.window_end = env::block_height() + job.window_blocks;
        self.jobs.insert(job_id, job.clone());
        Self::outcome(job_id, true, &job, "reveal_requested")
    }

    /// Worker answers the challenge by publishing the bytes that hash to the committed response_hash.
    pub fn reveal_response(&mut self, job_id: u64, response_bytes: Base64VecU8) -> Outcome {
        let mut job = self.job(job_id);
        require!(env::predecessor_account_id() == job.worker, "only the worker");
        require!(job.status == Status::Challenged, "no reveal requested");
        require!(env::block_height() <= job.window_end, "reveal window closed");
        require!(
            Some(hex(&env::sha256(&response_bytes.0))) == job.response_hash,
            "bytes do not hash to the delivered response_hash"
        );
        job.payload_bytes_onchain += response_bytes.0.len() as u32;
        let (d, w) = (job.delegator.clone(), job.worker.clone());
        self.bump(&d, |s| s.false_claims += 1);
        self.bump(&w, |s| s.jobs_no_fault += 1);
        let pay = [(w, job.price.0 + job.claim_bond.0), (d, job.kill_fee.0)];
        self.settle(job_id, job, Fault::FalseClaimByDelegator, "bytes_revealed_match_receipt", &pay, 0)
    }

    /// Allegation policies: the delegator blames the worker's output. Bond 0.25 NEAR.
    /// OptimisticAllegation: stored, NOT evaluated. CheckedAllegation: evaluated here.
    #[payable]
    pub fn allege(&mut self, job_id: u64) -> Outcome {
        let mut job = self.job(job_id);
        require!(env::predecessor_account_id() == job.delegator, "only the delegator");
        require!(job.status == Status::Delivered, "nothing to allege");
        require!(env::block_height() <= job.window_end, "filing window closed");
        let bond = env::attached_deposit().as_yoctonear();
        require!(bond == W_BOND, "attach exactly 0.25 NEAR");
        match job.policy {
            Policy::OptimisticAllegation => {
                job.claim_bond = U128(bond);
                job.claimant = Some(job.delegator.clone());
                self.take(&mut job, bond);
                job.status = Status::Alleged;
                job.window_end = env::block_height() + job.window_blocks;
                self.jobs.insert(job_id, job.clone());
                Self::outcome(job_id, true, &job, "allegation_filed_unchecked")
            }
            Policy::CheckedAllegation => {
                let verdict = self.check_receipt(
                    &job.model_id,
                    &job.request_hash,
                    job.response_hash.as_deref().unwrap_or(""),
                    job.signature.as_deref().unwrap_or(""),
                );
                let (d, w) = (job.delegator.clone(), job.worker.clone());
                match verdict {
                    Ok(_) => {
                        // Disproved at filing. Bond is returned as credit; nothing is locked; job unchanged.
                        self.total_in += bond;
                        self.credit(&d, bond);
                        self.bump(&d, |s| s.false_claims += 1);
                        Self::outcome(job_id, false, &job, "allegation_disproved_at_filing")
                    }
                    Err(reason) => {
                        job.claim_bond = U128(bond);
                        self.take(&mut job, bond);
                        self.bump(&w, |s| s.receipt_faults += 1);
                        let r = reward(W_RESERVATION);
                        let pay = [
                            (d, job.delegator_collateral.0 + bond + r),
                            (w, job.worker_collateral.0 - W_RESERVATION),
                        ];
                        self.settle(job_id, job, Fault::WorkerReceipt, &reason, &pay, W_RESERVATION - r)
                    }
                }
            }
            _ => env::panic_str("policy has no allegation path"),
        }
    }

    /// OptimisticAllegation: anyone may challenge with a 0.25 NEAR bond; the evaluator runs atomically.
    #[payable]
    pub fn challenge(&mut self, job_id: u64) -> Outcome {
        let mut job = self.job(job_id);
        require!(job.policy == Policy::OptimisticAllegation && job.status == Status::Alleged, "nothing to challenge");
        require!(env::block_height() <= job.window_end, "defense window closed");
        let bond = env::attached_deposit().as_yoctonear();
        require!(bond == W_BOND, "attach exactly 0.25 NEAR");
        let challenger = env::predecessor_account_id();
        self.take(&mut job, bond);
        let verdict = self.check_receipt(
            &job.model_id,
            &job.request_hash,
            job.response_hash.as_deref().unwrap_or(""),
            job.signature.as_deref().unwrap_or(""),
        );
        let (d, w) = (job.delegator.clone(), job.worker.clone());
        match verdict {
            Ok(_) => {
                // Overturned: the reporter's bond is the slashed pool.
                self.bump(&d, |s| s.false_claims += 1);
                let r = reward(job.claim_bond.0);
                let pay = [
                    (challenger, bond + r),
                    (d, job.delegator_collateral.0),
                    (w, job.worker_collateral.0),
                ];
                let t = job.claim_bond.0 - r;
                self.settle(job_id, job, Fault::FalseClaimByDelegator, "allegation_overturned_on_challenge", &pay, t)
            }
            Err(reason) => {
                // Upheld: reservation + challenger bond are the slashed pool.
                self.bump(&w, |s| s.receipt_faults += 1);
                let pool = W_RESERVATION + bond;
                let r = reward(pool);
                let pay = [
                    (d, job.delegator_collateral.0 + job.claim_bond.0 + r),
                    (w, job.worker_collateral.0 - W_RESERVATION),
                ];
                self.settle(job_id, job, Fault::WorkerReceipt, &reason, &pay, pool - r)
            }
        }
    }

    /// Permissionless: apply whatever the passage of blocks has decided.
    pub fn finalize(&mut self, job_id: u64) -> Outcome {
        let job = self.job(job_id);
        let h = env::block_height();
        let (d, w) = (job.delegator.clone(), job.worker.clone());
        let is_w = matches!(job.policy, Policy::OptimisticAllegation | Policy::CheckedAllegation);
        match job.status {
            Status::Open => {
                require!(h > job.deadline_block, "deadline not reached");
                if is_w {
                    // Handoff: unfinished edges release without inventing a fault from absence alone.
                    let pay = [(d, job.delegator_collateral.0), (w, job.worker_collateral.0)];
                    return self.settle(job_id, job, Fault::NoFault, "released_unfinished_no_fault", &pay, 0);
                }
                self.bump(&w, |s| s.no_receipt += 1);
                let pay = [(d, job.price.0 + job.kill_fee.0)];
                self.settle(job_id, job, Fault::WorkerNoReceipt, "no_valid_receipt_by_deadline", &pay, 0)
            }
            Status::Delivered => {
                require!(h > job.window_end, "window still open");
                if is_w {
                    let pay = [(d, job.delegator_collateral.0), (w, job.worker_collateral.0)];
                    return self.settle(job_id, job, Fault::NoFault, "released_no_claim", &pay, 0);
                }
                self.pay_success(job_id, job, "receipt_valid_window_elapsed")
            }
            Status::Challenged => {
                require!(h > job.window_end, "reveal window still open");
                self.bump(&w, |s| s.withheld += 1);
                let pay = [(d, job.price.0 + job.kill_fee.0 + job.claim_bond.0)];
                self.settle(job_id, job, Fault::WorkerWithheld, "response_bytes_not_revealed", &pay, 0)
            }
            Status::Alleged => {
                require!(h > job.window_end, "defense window still open");
                // Handoff policy: the allegation settles as filed. The evaluator never ran.
                self.bump(&w, |s| s.blamed_unchecked += 1);
                let r = reward(W_RESERVATION);
                let pay = [
                    (d, job.delegator_collateral.0 + job.claim_bond.0 + r),
                    (w, job.worker_collateral.0 - W_RESERVATION),
                ];
                self.settle(job_id, job, Fault::UncheckedBlameAccepted, "unchallenged_allegation_final", &pay, W_RESERVATION - r)
            }
            Status::Settled => env::panic_str("already settled"),
        }
    }

    /// Pull payment. Probe-grade: no failure callback (WBTS v2 has the careful version).
    pub fn withdraw(&mut self) -> Promise {
        let who = env::predecessor_account_id();
        let amount = self.credits.get(&who).copied().unwrap_or(0);
        require!(amount > 0, "nothing to withdraw");
        self.credits.insert(who.clone(), 0);
        self.sum_credits -= amount;
        self.total_out += amount;
        Promise::new(who).transfer(NearToken::from_yoctonear(amount))
    }

    // ---------- views ----------

    pub fn get_job(&self, job_id: u64) -> Job {
        self.job(job_id)
    }

    pub fn credit_of(&self, account: AccountId) -> U128 {
        U128(self.credits.get(&account).copied().unwrap_or(0))
    }

    pub fn stats_of(&self, account: AccountId) -> Stats {
        self.stats.get(&account).cloned().unwrap_or_default()
    }

    pub fn audit(&self) -> Audit {
        Audit {
            total_in: U128(self.total_in),
            locked: U128(self.locked),
            sum_credits: U128(self.sum_credits),
            treasury: U128(self.treasury),
            total_out: U128(self.total_out),
            conserved: self.total_in == self.locked + self.sum_credits + self.treasury + self.total_out,
        }
    }
}

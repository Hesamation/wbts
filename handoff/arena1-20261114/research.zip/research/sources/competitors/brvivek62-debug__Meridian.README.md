# Meridian

**The line your agents can't cross.**

An on-chain Vault contract on NEAR enforces spending limits — budget, per-transaction cap, daily cap, vendor allowlist, approval threshold — on every payment an AI agent makes, so a compromised or prompt-injected agent still can't move money outside what it was explicitly authorized to spend.

Built at NEAR HACKATHON. Tracks: `agents`, `security`, `swarms`. Status: feature-frozen for submission — see [Progress](#progress) for exactly what's done vs. in progress.

**Live demo (testnet):** [meridian-zeta-murex.vercel.app](https://meridian-zeta-murex.vercel.app)
**Try to break it:** [`/break`](https://meridian-zeta-murex.vercel.app/break) — a real NEAR AI Cloud tool-calling agent with a real NEAR wallet. Convince it to pay you; see whether the Vault lets it.

## Try it in 30 seconds

1. Open [`/break`](https://meridian-zeta-murex.vercel.app/break) and send it a message trying to get it to pay you — a fake bug-bounty reward, a claim that you're owed a refund, anything. **See:** the agent's reply, and "the line" animation showing what it tried to do.
2. If it decided to pay, **see:** the Vault either executes it (only if you happen to be its one allowlisted vendor — you aren't) or blocks it on-chain in real time, with the reason and a live testnet tx link. The scoreboard and "Hall of attempts" update either way — that history is kept, not reset, as proof.
3. Open the dashboard root ([meridian-zeta-murex.vercel.app](https://meridian-zeta-murex.vercel.app)) and look at the receipts feed. **See:** every `Blocked` entry (red) is a real on-chain policy violation from past runs, not a UI mock, and the delegation tree shows the real parent → sub-mandate structure.

## Problem

Giving an AI agent a NEAR account's full-access key means it can sign literally any transaction — a plain transfer, a call to any contract, anything. If the agent is compromised, misconfigured, or talked into something via prompt injection (a message embedded in a task, a tool result, or a webpage it reads), there is no technical limit on what it can do with that key. The usual mitigation — not giving the agent any money at all — also means it can't do anything useful: pay for an API, hire another agent, or settle a bill.

## Solution

Funds never sit behind the agent's own key. They sit in an on-chain Vault contract. The owner funds a **mandate** for the agent: a budget, a per-transaction cap, a daily cap, a vendor allowlist, and an approval threshold for anything above a given size. The agent's NEAR account holds only a **function-call access key** scoped to the Vault contract — it cannot do a plain transfer or call anything else, full stop, enforced by NEAR's own access-key validation before a transaction ever reaches a contract (proven on-chain by `npm run prove-no-bypass`). Every `pay` the agent makes is checked against its mandate on-chain; a violation is logged as a `Blocked` receipt instead of panicking, so a blocked attempt is visible, not hidden. Agents can delegate narrower **sub-mandates** to other agents (never broader than their own), hire each other through **escrow** (post a task, collect bids, lock funds, release on delivery), and — experimentally — pay on other chains via **Chain Signatures**. The [`/break`](https://meridian-zeta-murex.vercel.app/break) page is this claim made testable: a real agent, a real wallet, try and see.

## Architecture

```mermaid
flowchart LR
    Owner -->|create_mandate / approve / reject / revoke| Vault[(Vault contract)]
    Agent -->|pay / post_task / accept_bid / release / create_sub_mandate| Vault
    Vault --> Check{within mandate?}
    Check -->|yes, under threshold| Paid[transfer + Payment receipt]
    Check -->|yes, over threshold| Pending[PendingPayment -- owner approves/rejects]
    Check -->|no| Blocked[Blocked receipt -- nothing moves]
    Agent -->|create_sub_mandate: narrower only| SubAgent[sub-mandate agent, e.g. worker-summarizer]
    SubAgent -->|pay, within its own narrower mandate| Vault
    Paid --> Vendor[paid-api / worker-scraper / worker-summarizer]
    Dashboard[dashboard, view-only polling] --> Vault
    BreakAgent[break-agent, public /break, isolated mandate] -->|pay| Vault
    Agent -.->|authorize_foreign_payment, experimental| Vault
    Vault -.->|if Authorized| MPC[NEAR MPC signer -- Sepolia tx]
```

```
contracts/vault/   Rust Vault contract (near-sdk, cargo-near) → NEAR testnet
agent/             TypeScript LLM agent loop + NEAR client
vendors/           Paid API (HTTP 402) + worker agents
dashboard/         Next.js + Tailwind dashboard
scripts/           Deploy, seed, demo-run scripts
```

## NEAR features used

- **Function-call access keys** — the core security mechanism (see [Problem](#problem)/[Solution](#solution) and the trust model below). Every demo account (`agent`, `worker-scraper`, `worker-summarizer`, `break-agent`, `sepolia-agent`) holds one scoped to the Vault and a specific method list, never a full-access key.
- **NEP-297 event logs** — every receipt (`Payment`, `Pending`, `Blocked`, `EscrowLock`/`Release`, `Refund`, `Delegation`) is emitted as `EVENT_JSON:{"standard":"meridian",...}` (`contracts/vault/src/lib.rs`) in addition to being stored for view calls.
- **NEAR AI Cloud** — the OpenAI-compatible API (`openai` npm package) powers the agent's tool-calling loop (M5/M6), `worker-summarizer`'s summarization, the public `/break` agent, and the dashboard's plain-English-to-mandate parser.
- **Chain Signatures** (experimental, feature-frozen) — `v1.signer-prod.testnet`, via `chainsig.js`, for deriving an Ethereum Sepolia address and (once funded) signing a cross-chain payment. See the trust model below for exactly what's proven vs. in progress.
- **NEAR Intents (1Click API)** — not implemented. Scoped as S2 in `PLAN.md` and not reached before the feature freeze; see [Roadmap](#roadmap).

## Trust model

### Enforced on-chain by the Vault contract
- An agent spends only through the Vault. Every `pay`, `accept_bid` and `create_sub_mandate` is checked against the mandate: active, remaining budget, per-transaction cap, daily cap (24h window), and vendor allowlist.
- Violations are recorded as `Blocked` receipts. The agent cannot hide a failed attempt.
- Payments above the approval threshold wait for the owner. `approve` re-runs every check at approval time. Escrow above the threshold is blocked, so escrow cannot be used to skip approval.
- A sub-mandate can never have more authority than its parent: every limit must be ≤ the parent's, its allowlist must be a subset, and its budget comes out of the parent's remaining budget.
- The owner can `revoke` a mandate at any time. It deactivates the whole subtree and refunds the unspent budget.
- **Agent key restriction.** `agent.vivek-meridian.testnet` holds only a function-call access key (`scripts/setup-agent-key.ts`, M5) scoped to `vault.vivek-meridian.testnet` and the Vault's agent-side methods only (`pay`, `post_task`, `accept_bid`, `release`, `refund`, `create_sub_mandate`). Its full-access key was removed in the same transaction. This is enforced by NEAR's own access-key validation, not by Vault contract code — a plain transfer or a call to any other method is rejected before it ever reaches a contract, as proven by `npm run prove-no-bypass` (`scripts/prove-key-restriction.ts`).
- **Worker key restriction (M6).** The same pattern (`scripts/lib/keys.ts`, shared by `setup-agent-key.ts` and `setup-worker-keys.ts`) restricts `worker-scraper.vivek-meridian.testnet` to `submit_bid` only, and `worker-summarizer.vivek-meridian.testnet` to `submit_bid` + `pay` — the latter because once it is granted a sub-mandate, it also spends through the Vault on its own. Neither worker account can ever hold or move funds outside a Vault-checked call.

### Not enforced on-chain (yet)
- **Chain Signatures cross-chain payments (S1, experimental, feature-frozen).** `authorize_foreign_payment` (the Vault method that checks a mandate's foreign-payment allowlist/caps/budget and logs an `Authorized`/`Blocked` receipt) is implemented and proven on testnet — see the real tx links below. What is **not** done is the MPC-signing half: `sepolia-agent.vivek-meridian.testnet` is correctly restricted to call only `authorize_foreign_payment` (nothing else, not even `pay`), but the account that actually asks NEAR's MPC signer (`v1.signer-prod.testnet`) to sign the Sepolia transaction, `mpc-signer-3.vivek-meridian.testnet`, had to be given a **full-access key**, because `chainsig.js`'s `sign()` action always attaches a 1 yoctoNEAR deposit and NEAR's protocol flatly rejects any deposit on a call signed by a function-call-restricted key — no allowance setting can fix that. So the link between "the Vault authorized this" and "the MPC signer actually signs it" is enforced only by our own TypeScript control flow (`agent/src/chainSig.ts` always calls `authorize_foreign_payment` first and only proceeds to `sign` if the result is `Authorized`), not by a NEAR-level guarantee the way the Vault's other policy checks are. The derived agent Sepolia wallet also hasn't been funded with testnet ETH yet, so no signed Sepolia transaction has actually been broadcast. The honest status: **implemented — Vault-side authorization + Sepolia address derivation; in progress — MPC signing.** `scripts/demo-s1.ts` (`npm run demo:s1`) is marked experimental and is not wired into the dashboard or `npm run demo`. Roadmap: either give `mpc-signer` its own narrowly-scoped contract that wraps `sign()` without a caller-supplied deposit, or move to the fully on-chain-enforced design where the Vault contract itself calls the MPC signer.
- **Contract upgrades.** `vault.vivek-meridian.testnet` keeps a full-access key held by the deployer, so the deployer can replace the code. The on-chain code hash is listed under [Deployments and proofs](#deployments-and-proofs) for anyone to check. A production Vault would remove that key or hand upgrades to a DAO.
- **Delivery.** The Vault does not know whether a vendor delivered what was paid for. Paid-API access is verified by the vendor, off-chain. Escrow release is the poster agent's decision (or the owner's).
- **Combined daily spend across a delegation tree.** Daily caps are per mandate. A parent and its sub-mandates can together spend more in one day than the parent's daily cap, though never more than the parent's total budget.
- **Pending payments do not reserve funds.** That is why `approve` re-checks the policy.

### Storage cost
The Vault pays NEAR storage staking for everything it stores: mandates, receipts (including `Blocked` ones), pending payments, tasks and bids. Anyone can create a mandate (minimum 0.1 NEAR budget) and anyone can bid on an open task, so storage use is bounded by hard caps rather than paid by the caller:
- allowlist ≤ 20 entries, memo ≤ 256 bytes, task description ≤ 512 bytes
- ≤ 5 sub-mandates per mandate, delegation depth ≤ 2
- ≤ 50 pending payments per owner, ≤ 20 bidders per task (re-bidding replaces the bid)
- callers other than the mandate's agent or owner are rejected before anything is stored

Receipt history still grows with agent activity, and the Vault account must keep enough NEAR for storage. A production version would charge callers a storage deposit (NEP-145 style) instead.

### Public demo hardening (the hosted deploy, not the Vault)
Hosting the dashboard publicly adds attack surface that has nothing to do with the Vault's own guarantees above — anyone can reach the API routes, not just the owner's browser:
- **`READ_ONLY_OWNER_ACTIONS=true`** (set on the Vercel deploy only). `demo-owner`'s private key lives in that deploy's env vars; without this, anyone with the URL could sign transactions as demo-owner. With it, `POST /api/mandates` and `POST /api/pending/[id]` return 403 before signing anything, and the dashboard disables the Create mandate / Approve / Reject controls with the same note. The "describe the rules in your own words" NEAR AI parse step keeps working either way — it never signs anything.
- **Rate limits on every NEAR AI-backed route**, independent of the Vault: `/api/break` (5/IP/10min, 200/day globally, backed by Upstash Redis on the hosted deploy — see [`/break`](#break-meridian-public-challenge-break) below) and `/api/parse-mandate` (10/IP/hour, `dashboard/lib/rateLimit.ts`), so a visitor can't run up the NEAR AI Cloud bill even though no NEAR ever moves from that route.
- **RPC resilience.** `dashboard/lib/near.ts` caches Vault view calls for ~5s and uses a `FailoverRpcProvider` across two independent testnet RPC endpoints, so concurrent visitors polling the dashboard don't trip fastnear's public rate limit.
- **Health check.** `scripts/check-deploy-health.sh [live-url]` curls the live site and the testnet accounts' balances (vault, break-agent, demo-owner, and the owner itself — its own wallet only ever needs gas, since the NEAR it deposits into a mandate lives in the Vault, not in the owner's own balance), warning (non-zero exit) if any looks low; `.github/workflows/deploy-health.yml` runs it on a schedule with no repo secrets needed.

## Run locally

**Prerequisites:** Node ≥ 20; Rust + the `wasm32-unknown-unknown` target (`rustup target add wasm32-unknown-unknown`); [`cargo-near`](https://github.com/near/cargo-near) (`cargo install cargo-near`); [near-cli-rs](https://github.com/near/near-cli-rs); a funded NEAR testnet account (see [Q-008](HACKATHON.md) for a faucet) with its key in the near-cli-rs keychain. Verified by cloning this repo fresh and following every step below in order on 2026-11-14.

### One command (M8)

After the setup steps below (deploy, seed, agent/worker keys — everything through [the agent marketplace section](#the-agent-marketplace-workers-bidding-sub-mandates-m6)) have been run once:

```bash
npm run reset-demo   # optional, for the tidiest single run — see below
npm run demo         # the whole story end to end on testnet, one command
```

`scripts/demo.ts` reproduces PLAN.md's 3-minute demo script in order: paid-API 402 flow (M5) → worker bidding, counter-offer, escrow lock/release (M6) → a 1 NEAR sub-mandate for `worker-summarizer` → an approval-threshold payment that goes `Pending` and is then `approve`d by the owner → a blocked attack (`pay` to `attacker.testnet`, not on the allowlist) → a recap with every real tx's explorer link. It starts and tears down `paid-api` + both workers itself.

**Safe to run repeatedly.** It reuses the existing production mandate rather than creating a new one, and the approval-payment step adapts its amount to (or skips cleanly, with a clear message, instead of crashing, if) the mandate's remaining per-tx/daily-cap/budget headroom — repeated same-day runs can legitimately exhaust the mandate's **daily cap** (the Vault enforcing its own policy, not a bug), in which case that one step is skipped. Run `npm run reset-demo` first for the cleanest single run, or wait for the 24h daily-cap rollover. The attack step always works regardless, since it's Blocked before anything moves.

### Step by step

1. `cp .env.example .env` and fill in values.

### Vault contract: build and test

```bash
cd contracts/vault
cargo near build non-reproducible-wasm   # → target/near/vault.wasm
cargo test                               # unit tests + sandbox tests
```

Sandbox tests use `near-sandbox` + `near-api` (what `cargo near new` generates now, in place of `near-workspaces`) and run on Apple Silicon. The 24h daily-cap rollover is unit-tested with `testing_env!` rather than sandbox-tested: sandbox `fast_forward` moves the clock only ~0.4 s per block here, so 24h would take ~35 min per run. Details: [contracts/vault/README.md](contracts/vault/README.md). First run downloads the `near-sandbox` binary, so `tests/sandbox.rs`'s 8 tests can take a few minutes the first time and under 20s after that.

### Deploy to testnet and seed

Requires Node ≥ 20, [near-cli-rs](https://github.com/near/near-cli-rs), and a funded testnet owner account whose key is in the near-cli-rs keychain.

```bash
npm install
cp .env.example .env        # set OWNER_ACCOUNT_ID=<you>.testnet
(cd contracts/vault && cargo near build non-reproducible-wasm)
npm run deploy              # → creates vault/agent/worker-scraper/worker-summarizer/paid-api.<owner>, deploys the Vault
npm run seed                # → owner creates a 5 NEAR mandate, agent pays 0.1 NEAR to paid-api: prints "Paid"
```

Both scripts are idempotent: a re-run skips accounts, code and the seed mandate that already exist. They write public account ids and tx hashes to [`deployments/testnet.json`](deployments/testnet.json). The scripts refuse to run unless `NEAR_NETWORK=testnet`.

**Keys.** The owner's key never leaves the near-cli-rs keychain: owner transactions (account creation, `create_mandate`) are signed by `near ... sign-with-keychain`. Each demo account gets a new key, written only to `~/.near-credentials/testnet/<account>.json` (mode 600). No key is in this repository or in `.env`.

The deploy funds the Vault with 3 NEAR: ~2.46 NEAR covers code storage (245 KB) and the rest pays for mandate and receipt storage. The seed needs 5 NEAR for the mandate and keeps a 3 NEAR reserve in the owner (`SEED_OWNER_RESERVE`). If the owner is short, get testnet NEAR from a faucet (see [Q-008](HACKATHON.md)).

### Agent key restriction, paid API, and the agent loop (M5)

```bash
npm run setup-agent-key     # agent.<owner>: full-access key → function-call key scoped to the Vault, one-shot
npm run prove-no-bypass     # proves a direct transfer and a non-allowed Vault method both get rejected by NEAR itself
npm run demo:m5             # starts vendors/paid-api, runs the agent, shows 402 → pay via Vault → data end to end
```

`setup-agent-key` is idempotent — re-running it after the agent is already restricted is a no-op. The agent (`agent/`) runs an LLM tool-calling loop on **NEAR AI Cloud** (OpenAI-compatible, `openai` npm package, model `LLM_MODEL` from `.env`) with two tools: `check_budget` (reads the mandate from the Vault) and `call_paid_api` (GETs a URL, and on a 402 pays the quoted price through `Vault.pay` and retries automatically — this is the agent's *only* way to move NEAR, since its key cannot do a plain transfer). `vendors/paid-api` (`npm run paid-api`) is the other side: it answers `GET /data?q=...` with `402 { price, payTo, memoNonce }` when there's no `X-Payment-Tx` header, and with one, verifies through NEAR testnet RPC — not by trusting the client — that the transaction called `Vault.pay`, paid at least the price to itself, carried the issued nonce in the memo, and actually succeeded on-chain, before returning data. It rejects a replayed tx hash.

To run the two halves by hand instead of `demo:m5`: `npm run paid-api` in one terminal, then `npm run agent -- "your research question"` in another.

### The agent marketplace: workers, bidding, sub-mandates (M6)

```bash
npm run setup-worker-keys   # worker-scraper, worker-summarizer: full-access key → function-call key scoped to the Vault, one-shot
npm run demo:m6             # starts paid-api + both workers, runs the agent in marketplace mode, prints a colored recap
```

`setup-worker-keys` is idempotent, same pattern as `setup-agent-key` (shared logic in `scripts/lib/keys.ts`). `worker-scraper.<owner>.testnet` gets a key restricted to `submit_bid` only — it only ever acts as a bidder. `worker-summarizer.<owner>.testnet` gets `submit_bid` + `pay`, because once it is granted a sub-mandate it also spends through the Vault on its own.

`vendors/worker-scraper` and `vendors/worker-summarizer` (`vendors/worker-common/service.ts` holds the shared scaffolding) each run a small Express service that:
- polls `Vault.get_tasks` for open tasks posted by the agent and calls `submit_bid` with a starting price;
- answers **one** counter-offer over HTTP (`POST /counter-offer { taskId, priceNear }`) — it accepts (and resubmits its bid on-chain at the new price) if the offer is at or above its own minimum price, otherwise it rejects and its current bid stands; a second call for the same task just replays its first decision;
- delivers the work once it has won a task (`GET /deliver/:taskId`) — `worker-scraper` returns mock scraped data, `worker-summarizer` watches `get_mandates_by_owner` for a new active mandate granted to itself and, once one appears, autonomously pays `vendors/paid-api` through that sub-mandate (the only way its key can move NEAR) and calls **NEAR AI Cloud** to summarize the result.

The agent (`npm run agent -- --m6`) gets six more tools on top of M5's two: `post_task`, `list_bids` (polls until enough bids arrive or it times out), `counter_offer`, `accept_bid`, `release_escrow` (fetches the winner's delivery, then releases the payment), and `create_sub_mandate`. Its M6 run: posts a scraping task → waits for both workers' bids → counter-offers the cheaper one → accepts the best final price (escrow locks) → receives the work and releases payment → delegates a 1 NEAR sub-mandate to `worker-summarizer`, which then pays and summarizes on its own. `npm run demo:m6` runs all of this in one command and prints a colored log with testnet explorer links for every on-chain step, plus a recap.

To run the pieces by hand instead of `demo:m6`: `npm run paid-api`, `npm run worker-scraper`, `npm run worker-summarizer` in three terminals, then `npm run agent:m6` in a fourth.

### Dashboard (M7)

`dashboard/` is its own package (not an npm workspace of the root `package.json`), so it needs its own install once:

```bash
npm install --prefix dashboard
npm run setup-dashboard     # creates demo-owner.<owner>.testnet, writes its key to .env, one-shot
npm run dashboard           # → http://localhost:3000
```

`dashboard/` is a Next.js (App Router) + Tailwind app that polls the Vault's view methods over testnet RPC every 4s — it never needs a key to read. It shows, for every mandate it finds (the real owner's and the dashboard's own sandbox ones): a budget meter (spent/locked/delegated vs. budget, caps, allowlist chips), a receipts feed (Payment, Pending, Blocked in red, EscrowLock/Release, Refund, Delegation — a new Blocked receipt flashes red), a task board (open/locked/released, with bids and the final price), and a delegation tree (owner → mandate → sub-mandates, outline-only, no fills).

**Signing.** Owner-only actions — create mandate, approve, reject — and the attack button are server-side API routes (`dashboard/app/api/*`, Node runtime) signed by a dedicated `demo-owner.<owner>.testnet` account (`npm run setup-dashboard`), never the real owner's near-cli-rs keychain key. NEAR's testnet faucet only mints new top-level accounts, not sub-accounts of an existing one, so — like every other demo account in this repo — demo-owner is funded from the real owner's balance, not a third-party faucet. Unlike those accounts, demo-owner's private key is written to `.env` (`DEMO_OWNER_PRIVATE_KEY`) rather than `~/.near-credentials`, so the dashboard's server can read it; it is never sent to the browser. The **Create mandate** form always creates new mandates owned by demo-owner (agent defaults to demo-owner too, so it can also approve/reject its own pending payments); the **Approvals inbox** shows the real owner's pending payments read-only (there usually aren't any, since M5/M6 payments stay under its 0.8 NEAR threshold) and lets the dashboard act only on demo-owner's own.

**Public demo lock (`READ_ONLY_OWNER_ACTIONS`).** demo-owner's key lives in the hosted deploy's env vars, so without a separate guard, anyone with the URL could sign transactions as demo-owner — create mandates against its balance, approve/reject its pending payments. Set `READ_ONLY_OWNER_ACTIONS=true` (set on the Vercel deploy; unset locally) and `POST /api/mandates` and `POST /api/pending/[id]` return 403 with "Owner actions are disabled on the public demo." *before* signing anything, and the dashboard disables the Create mandate and Approve/Reject buttons with the same note — the "describe the rules in your own words" → NEAR AI parse step still works, since it never signs a transaction. The flag only gates demo-owner's write paths; the Vault's own on-chain policy checks are unaffected and unconditional either way.
The **attack button** ("Inject malicious instruction") models a prompt-injected agent deciding to send everything to `attacker.testnet`: it calls `Vault.pay` directly with the target mandate's own agent key (the real agent's restricted key from `~/.near-credentials` for the production mandate, demo-owner's key for a sandbox one) for the mandate's full budget. The question isn't whether an LLM would refuse — ours does, in `agent/src/llm.ts` — it's that the Vault blocks it on-chain regardless, exactly as PLAN.md's demo script describes.

Because the Vault's `Receipt` doesn't record a transaction hash (only `Mandate`/`Task`/`Bid` ids and amounts), the receipts feed links each receipt's recipient to its explorer **account** page rather than a specific tx; every action the dashboard itself performs (create mandate, approve, reject, attack) shows the real tx hash and explorer link it gets back from signing that call.

Create Mandate also has a **"Describe the rules in your own words"** box: NEAR AI (JSON mode, `dashboard/lib/parseMandate.ts`) turns a plain-English description into the exact fields (budget, per-tx cap, daily cap, allowlist, approval threshold) and fills them in for review, with notes on any assumptions or inconsistencies it noticed. The button shows a "Parsing…" state and an "usually under 15s" message while it waits. Nothing is submitted until the owner reviews/edits the fields and clicks **Create mandate**, which stays disabled until client-side sanity checks pass (budget > 0; per-tx cap, daily cap and approval threshold each ≤ budget).

**Speed (2026-11-14).** `/api/parse-mandate` originally shared `LLM_MODEL` (`z-ai/glm-5.3-flash`) with the M5/M6 agent loop and measured 20-52s for this one-shot JSON call on live traffic. It now uses its own `PARSE_MANDATE_MODEL` (default `anthropic/claude-haiku-5-5`, benchmarked against several NEAR AI Cloud models with the same prompt) and measured ~3.5s locally for the same request — well under the 15s target. `LLM_MODEL` itself is untouched, since the M5/M6 tool-calling loop has different requirements than a single JSON call.

### "Break Meridian" public challenge (`/break`)

```bash
npm run setup-break-agent   # creates break-agent.<owner>.testnet + its own isolated mandate, one-shot
npm run dashboard           # → http://localhost:3000/break
```

"This AI agent controls a real wallet. Try to make it send you money." A visitor's plain-text message goes to **break-agent**, a real NEAR AI Cloud tool-calling loop (`dashboard/lib/breakAgent.ts`) with exactly two tools: `check_budget` and `send_payment`. Its system prompt does *not* hard-refuse everything — it's told to use judgment, so it's genuinely exploitable by social engineering, not a strawman. Unlike the production agent (`agent/src/llm.ts`), break-agent is never told its own limits: `check_budget` returns only its remaining spendable balance, never the allowlist, per-tx cap or daily cap, and its system prompt doesn't mention that those rules exist. The point of `/break` is that the Vault enforces the mandate even when the agent itself has no idea what it's allowed to do — so a convinced agent attempts the payment naively, and the chain is what actually stops it. If it decides to pay, `send_payment` calls `Vault.pay` for real, with break-agent's own restricted key.

Safety is on-chain, not in the prompt: `scripts/setup-break-agent.ts` gives break-agent its own mandate (2 NEAR budget, 0.05 NEAR per-tx cap, 0.2 NEAR daily cap) with an allowlist containing **only** the real paid-api vendor. A visitor's own account can never be on it, so talking the agent into sending money to an address the visitor controls is always `Blocked` on-chain — this is what `nearStolenYocto` actually tracks (`dashboard/lib/breakStore.ts`: a `Paid` attempt only counts as "stolen" if the money went somewhere *other than* the one legitimate vendor). There is one narrower way a convinced agent can still move real funds: being talked into re-paying its own already-allowlisted vendor under false pretenses (e.g. a fake unpaid-invoice claim) — the Vault correctly lets that through, since paid-api genuinely is on the allowlist, but the NEAR goes to the project's own vendor, never to the visitor, so it isn't theft, just an avoidable duplicate payment. This happened once in testing (0.02 NEAR, see the Deployments table below). Its account key is restricted to `Vault.pay` only, separate from every other demo account, so public traffic can't drain or interfere with the production or M7 demo mandates.

The page shows a live scoreboard (total attacks, agents fooled, NEAR stolen — always 0 if the Vault holds) and a "Hall of attempts" (last 10, message always rendered as plain text, never HTML), backed by a small storage interface (`dashboard/lib/breakStore.ts`) with a local JSON file for now. Rate limited to 5 attempts/IP/10min and 200/day globally (IPs kept only as a truncated hash); max 1000 characters; a `BREAK_ENABLED=false` kill switch. Uses a fast tool-calling NEAR AI Cloud model confirmed via the live `GET /v1/models` to support tool calling, configurable via `BREAK_MODEL`.

**Speed (2026-11-14).** A live `/api/break` run on `openai/gpt-5-nano` measured **26.9s** end-to-end (up to 4 LLM turns plus a real NEAR tx). Benchmarked against several alternatives with the same multi-turn check_budget/send_payment shape, `Qwen/Qwen3.8-27B` ran roughly 2x faster on the LLM side; repeated local runs after switching landed at **~9-12s** typical, occasionally ~24s on a slower RPC round-trip. The same bounty-style prompt that fooled `gpt-5-nano` in the recorded attempts below still fools `Qwen/Qwen3.8-27B` the same way (judges the request reasonable, attempts `send_payment`, the Vault blocks it on the allowlist) — the exploit characteristics didn't change, only the latency.

Both `/break` and the main dashboard show **"the line"** (`dashboard/components/TheLine.tsx`): a glowing vertical line between the agent and a target. Every attempt animates a coin from the agent toward the target — it shatters into particles with "BLOCKED" + the reason in red if the Vault stops it, passes through with a subtle blue pulse if paid, or dissolves before reaching the line if the agent never tried. Pure CSS keyframes, no animation library, each under 1.5s.

## Deployments and proofs

| Item | Value |
|---|---|
| Vault contract (testnet) | [`vault.vivek-meridian.testnet`](https://testnet.nearblocks.io/address/vault.vivek-meridian.testnet), code hash `42ZeciXtgZtd2UKKi88WMzUcg7RPgnG6pxYjGqE1Rn3M` |
| Vault deploy tx | [`FVrP5cmZ…GFR5`](https://testnet.nearblocks.io/txns/FVrP5cmZLQms5NfGW1wDSdAPHYPZ22q39tTPg2jrGFR5) |
| Seed mandate (5 NEAR, id 0) | [`9DZkqxPY…bpY7`](https://testnet.nearblocks.io/txns/9DZkqxPYUj8VjX6jdBu5Sr3Njftn744nTRopyK4PbpY7) |
| Test payment, 0.1 NEAR agent → paid-api (`Paid`) | [`CKLuXywE…pfzqW`](https://testnet.nearblocks.io/txns/CKLuXywEZAq6qL3zRBnZrYkDxguWADzPHTuPotMpfzqW) |
| Agent key restricted (full-access → function-call, scoped to Vault) | [`F9nxYdBv…8CKK`](https://testnet.nearblocks.io/txns/F9nxYdBv4SbDMyULCZfcEwVdRHEsyWutee4usAGA8CKK) |
| Agent → paid-api payment via 402 flow, 0.3 NEAR (`Paid`) | [`9JZEDEpV…rWsSY`](https://testnet.nearblocks.io/txns/9JZEDEpVW1x557crJdtD4P52co55Gq1Av36YSiZrWsSY) |
| worker-scraper key restricted (full-access → function-call, scoped to Vault) | [`AJRfaKnP…7Wfjmj`](https://testnet.nearblocks.io/txns/AJRfaKnPkQRBnTfdqhJ7JkNQcoyJroge5r6mpF7Wfjmj) |
| worker-summarizer key restricted (full-access → function-call, scoped to Vault) | [`Ede9EKm7…uviQ64`](https://testnet.nearblocks.io/txns/Ede9EKm75Qjd2E7KrShK5QzdXUu3NXTxjR98xAuviQ64) |
| M6 post_task (task 0, "Scrape NEAR agent wallet docs", max 0.4 NEAR) | [`43PQFjBm…4LQtUG`](https://testnet.nearblocks.io/txns/43PQFjBmWcdE69UMcuLff7CCPQFoM7LytzE3TV4LQtUG) |
| M6 bids: worker-scraper 0.3 NEAR, worker-summarizer 0.35 NEAR | [`Ef7GZRMA…nB5sE`](https://testnet.nearblocks.io/txns/Ef7GZRMAqRcPmziX5ZUc6AtBK6S5LUxzzj3qP1tnB5sE), [`HqXuBMoe…cqvZjH`](https://testnet.nearblocks.io/txns/HqXuBMoeJq7N4gnTvixzErRqTWkTGgnsDfU53bcqvZjH) |
| M6 counter-offer accepted: worker-scraper resubmits at 0.2 NEAR | [`36bQwwG1…Xn6WEt`](https://testnet.nearblocks.io/txns/36bQwwG1jLr7nQonh5qnyomp1WWz9wH2JD5XU9xn6WEt) |
| M6 accept_bid (escrow lock, worker-scraper @ 0.2 NEAR) | [`CtLLHXsz…MSUf9VG`](https://testnet.nearblocks.io/txns/CtLLHXszzZn1WE7NKzVR7S5eoPYAkzF6RfAd8MSUf9VG) |
| M6 release (escrow → worker-scraper, task `Released`) | [`745kcFZn…VYkHQS`](https://testnet.nearblocks.io/txns/745kcFZnasFvrdRpmJmj3itPBWRFWVD2NDy7UzVYkHQS) |
| M6 create_sub_mandate (1 NEAR for worker-summarizer, mandate id 1) | [`EeJVAmcE…T7aEPQBN`](https://testnet.nearblocks.io/txns/EeJVAmcEGhfFXdFUEBCUGbRvGbPqQeSpmWhbT7aEPQBN) |
| M6 worker-summarizer pay via its sub-mandate, 0.3 NEAR to paid-api | [`F6SRuTND…k59TX14o`](https://testnet.nearblocks.io/txns/F6SRuTNDy6C9bGZ7FhFEdHVZuKmJTVs6jQYuk59TX14o) |
| demo-owner account created (M7), funded 5 NEAR from the owner | [`EMWbRxeH…ZZv58`](https://testnet.nearblocks.io/txns/EMWbRxeHfeekmK9iyTmzk9U7UNQWpeuMJkPVMfYZZv58) |
| Dashboard create_mandate (demo mandate id 2, 2 NEAR, via demo-owner) | [`JAs46Xqf…Z0wAcb`](https://testnet.nearblocks.io/txns/JAs46XqfiLj34b42XHyPK3peHYHdHBBjJKK6gFeZwAcb) |
| Dashboard approve (pending → `Paid`, 0.45 NEAR) | [`Bm5A9qtd…a4t1Vf21`](https://testnet.nearblocks.io/txns/Bm5A9qtdi7v2WBDTnikzAR9JacPLEXXUjvxKa4t1Vf21) |
| Dashboard reject (`Rejected`) | [`6P2CaCcX…BZu91HL`](https://testnet.nearblocks.io/txns/6P2CaCcXTS29ZZoRxEKcXhp7UQv2yVqnUBtzBZu91HL) |
| Dashboard attack button on the production mandate 0 → `Blocked` | [`78xW26ic…z4Qn6oH`](https://testnet.nearblocks.io/txns/78xW26ic1JAA2nTuVPmS3u2GNcCwfhRu4F9YWz4Qn6oH) |
| break-agent created + key restricted to `Vault.pay` | [`GV81PqwsyY…ZnvCJ`](https://testnet.nearblocks.io/txns/GV81PqwsyYzQqB64pFJU4CUHMq6HU9vthQUeHa1ZnvCJ), [`LSHwcDbLjE…6NVB`](https://testnet.nearblocks.io/txns/LSHwcDbLjES9qjtb2QdFZXr8TSzNNxvWv9H7ULm6NVB) |
| break mandate 6 (2 NEAR, per-tx cap 0.05, daily cap 0.2, allowlist = paid-api only) | [`2eFPGKTDSh…BXuKS`](https://testnet.nearblocks.io/txns/2eFPGKTDShHJZomzRJmvbgZTWj5foxoWweAtW3tBXuKS) |
| `npm run reset-demo` (2026-11-14, feature freeze): revoked stray/duplicate mandates from repeated M6/dashboard testing, recreated exactly one production mandate (id 14, agent.vivek-meridian.testnet, 4.9172 NEAR — slightly under the usual 5 NEAR target since the owner's balance was tight) with exactly one worker-summarizer sub-mandate (id 15, 1 NEAR). break-agent's mandate (id 9, the one the live Vercel deploy's `BREAK_MANDATE_ID` env var points at) was deliberately left untouched — see `scripts/reset-demo.ts`'s header comment. | [`4NbrdAMg…QpGp`](https://testnet.nearblocks.io/txns/4NbrdAMg5TPTHEXvUpXX3DL395sgkc9tMHLXErLWQpGp) (mandate 14), [`CDitwkED…HUsQ`](https://testnet.nearblocks.io/txns/CDitwkED3wuu3cQVEK8m4vuypFWoCuZMm6myLJvmHUsQ) (sub-mandate 15) |
| `npm run demo` (M8, 2026-11-14): one run of the whole story — 402 payment, worker bidding + counter-offer + escrow release, sub-mandate, approval-threshold `Pending`→`approve`, blocked attack to `attacker.testnet`. Run twice back to back to prove repeatability (second run's approval step correctly skipped — same-day daily cap already used by the first run — everything else completed normally). | 402 payment [`6HzSLTJx…Lh2VR`](https://testnet.nearblocks.io/txns/6HzSLTJxh5caidR2sNVY16DQf3SviyuCthUnJC2Lh2VR) · escrow lock [`HdMF95QK…kdMz`](https://testnet.nearblocks.io/txns/HdMF95QKuQsekEmg1qmg2rv1hMDHgECgwfMcAspZkdMz) · escrow release [`FCBdd5rb…7zcq`](https://testnet.nearblocks.io/txns/FCBdd5rb4krv3Tw654nH4C4hbC6KFXAa4sEoHyyX7zcq) · sub-mandate [`Hvw7Bc4Q…MKaW`](https://testnet.nearblocks.io/txns/Hvw7Bc4QFkShzBpGby6KRuujhepAV7ybyrdqqryMwKaW) · pending [`ELg2DE7m…eWp1`](https://testnet.nearblocks.io/txns/ELg2DE7mThVdAzmnsKdEaKP5PVYgJjKXDc9BQf5oEWp1) → approved [`XVq23tZK…yq6`](https://testnet.nearblocks.io/txns/XVq23tZKeoBFpucAw5baDUTbEnjhHiDnjwBaXbZqyq6) · blocked attack [`D5huSZth…rXx4G`](https://testnet.nearblocks.io/txns/D5huSZthnjqMCY4GR8bwiWvEqS5UMT8gBfcnA52rXx4G) |
| `/break` attack attempts, live scoreboard as of 2026-11-14 (`GET /api/break`, Upstash Redis-backed, not reset — this is the actual current state of the Hall of Attempts, not a point-in-time local test): **7 total, 2 fooled the LLM into attempting a payment, 1 `Blocked` on-chain, 0 NEAR stolen** (`nearStolenYocto` only counts a `Paid` attempt whose destination wasn't the real paid-api vendor — see the trust-model note above). Of the 2 fooled: a fake bug-bounty payout to a visitor-named account was `Blocked` (not on the allowlist); a fake unpaid-invoice claim convinced it to re-pay its own real paid-api vendor, 0.02 NEAR — the Vault correctly allowed that one (paid-api *is* allowlisted), but the money went to the project's own vendor, not the visitor, hence 0 stolen. The other 4 recorded attempts are developer rate-limit/health-check probes that explicitly asked the agent to refuse, which it did. | fooled → `Blocked`: [`5QfQ4t768A…uvPvz`](https://testnet.nearblocks.io/txns/5QfQ4t768AKD3xHX3oiDK739mazPTne7DQwo8SxuvPvz) · fooled → `Paid` to paid-api: [`B592DVYK…C5f4hB`](https://testnet.nearblocks.io/txns/B592DVYKYnnGezzYhj5UQum5hJV98xdkiosJzMC5f4hB) |
| Demo accounts (testnet) | `agent`, `worker-scraper`, `worker-summarizer`, `paid-api`, `demo-owner`, `break-agent` `.vivek-meridian.testnet`; all ids and creation txs in [`deployments/testnet.json`](deployments/testnet.json) |
| Hosted demo (Vercel, testnet) | [meridian-zeta-murex.vercel.app](https://meridian-zeta-murex.vercel.app) — dashboard + [`/break`](https://meridian-zeta-murex.vercel.app/break), Upstash Redis-backed, up until at least 2026-11-25 |
| Balances topped up for the hosted demo (2026-11-13, from two faucet-sponsored accounts, `scripts/check-deploy-health.sh` to re-check) | `vault`: 19.02 NEAR (~16.4 NEAR spendable over the ~2.65 NEAR already locked for storage) · `break-agent`: 4.30 NEAR (gas only — its key never attaches a deposit) · `demo-owner`: 5.60 NEAR · `owner`: 3.90 NEAR — comfortably covers 200 attacks/day through 2026-11-25 |
| Demo video | _TODO_ |
| Chain Signatures (S1, experimental): `authorize_foreign_payment` — Vault-side authorization proven on testnet. **Authorized** (vendor on allowlist) | [`6D9oxnsy…obSC`](https://testnet.nearblocks.io/txns/6D9oxnsyWnBsmvkgDcY7oKF8GghUJ5SJbG45F7KMobSC) |
| Chain Signatures (S1): `authorize_foreign_payment` **Blocked** (destination not on allowlist) | [`DG3ZLKJ4…Cisq`](https://testnet.nearblocks.io/txns/DG3ZLKJ4cmkN94TsapLGJevv97vMYBQVNEpZRU3YCisq) |
| Chain Signatures (S1) MPC-signed Sepolia payment tx | _not yet run — agent's derived Sepolia wallet needs testnet ETH; see trust-model note above_ |
| NEAR Intents swap (mainnet) tx | _TODO_ |

## Libraries, templates and tools used

- AI coding tools: this project is built with Claude Code.
- `cargo near new` project template (Vault scaffold)
- Rust: `near-sdk` 5.30; tests: `near-sandbox`, `near-api`, `cargo-near-build`, `tokio`, `testresult`
- Node scripts: `near-api-js` 7.4, `tsx`, `dotenv`, `typescript`; `near-cli-rs` for owner-signed transactions
- Agent and paid API (M5): `openai` 7.55 (OpenAI-compatible client, pointed at NEAR AI Cloud), `express` 5.3
- Worker marketplace (M6): same `openai`/`express`/`near-api-js`, no new dependencies
- Dashboard (M7): Next.js 16, React 19, Tailwind CSS 4, `near-api-js` (its own `dashboard/package.json`)
- Break Meridian challenge + plain-English mandates: `openai` (NEAR AI Cloud, added to `dashboard/package.json`), no new dependencies otherwise — "the line" animation is pure CSS keyframes, no animation library

## Roadmap

- **Finish Chain Signatures (S1).** Fund the derived Sepolia wallet and get one real MPC-signed Sepolia transaction end to end; move `mpc-signer` off a full-access key, either by giving it its own narrow wrapper contract around `sign()` or by moving to the fully on-chain-enforced design where the Vault contract itself calls the MPC signer (the ideal referenced in `PLAN.md`).
- **NEAR Intents (S2), not started.** A live `/v0/tokens` + `dry: true` quote in the dashboard, and one small real mainnet swap from a dedicated dev account, as `PLAN.md` describes.
- **Combined daily spend across a delegation tree.** Daily caps are per-mandate today; a parent and its sub-mandates can together exceed what the parent's own daily cap would suggest, though never more than the parent's total budget. Tracking this across a subtree on-chain is the natural next policy check.
- **Storage deposits.** The Vault currently pays its own NEAR storage staking for every mandate, receipt, pending payment, task and bid, bounded only by hard caps (see [Storage cost](#storage-cost)). A NEP-145-style deposit from the caller would let those caps be relaxed.
- **Contract upgrade governance.** `vault.vivek-meridian.testnet` keeps a deployer-held full-access key for upgrades. Removing it (freezing the code) or handing upgrades to a DAO would close that gap.
- **Mainnet.** Everything here is testnet-only (NEAR side) and a few small mainnet-dev-account swaps (Intents side, once S2 lands); a real deployment would need a security review of the Vault contract first.

## Team

spider sensi

## License

[MIT](LICENSE)

## Progress

### MUST
- [x] M1 Repo scaffold, `.gitignore`, `.env.example`, README skeleton
- [x] M2 Vault contract: mandates, `pay`, policy checks, receipts, tests
- [x] M3 Pending approvals, sub-mandates, escrow, revoke, tests
- [x] M4 Testnet deploy, `scripts/deploy.ts`, `scripts/seed.ts`
- [x] M5 Agent with restricted function-call key + paid-API 402 flow
- [x] M6 Worker agents, bidding, counter-offer, escrow release
- [x] M7 Dashboard: create mandate, live receipts, approvals, attack button
- [x] M8 `scripts/demo.ts` runs the full demo in one command (`npm run demo`), verified to run twice back to back

### SHOULD
- [~] S1 Chain Signatures (experimental, feature-frozen): Vault-side `authorize_foreign_payment` implemented + proven on testnet (real tx links above); MPC signing of the actual Sepolia tx in progress, not yet completed
- [ ] S2 1Click quote in live flow + one real mainnet swap recorded
- [x] S3 Delegation tree visualization

### Extras (Nov 12)
- [x] "Break Meridian" public challenge at `/break`: real NEAR AI tool-calling agent (check_budget + send_payment), isolated mandate + restricted key, scoreboard, Hall of attempts, rate limiting, kill switch — 5 attack styles tested on testnet, 3 fooled the LLM, Vault blocked all 3, 0 NEAR stolen
- [x] break-agent no longer told its own limits (check_budget returns only remaining balance; system prompt never mentions allowlist/caps), so it can't self-censor based on knowing the rules — re-ran the 5 attacks after the change, same result: 3/5 fooled, Vault blocked all 3

  _(These two Nov 12 numbers are local-dev-storage results from before the Nov 13 move to Upstash Redis, kept here as a changelog entry. For the actual current state of the live Hall of Attempts, see the `/break` row in [Deployments and proofs](#deployments-and-proofs) — it includes one real fooled-and-`Paid` case the Nov 12 testing didn't hit, where the agent re-paid its own legitimate vendor under false pretenses.)_
- [x] "The line" animation (`TheLine.tsx`) on `/break` and the dashboard — pure CSS, blocked/paid/refused states, under 1.5s
- [x] Plain-English mandates: "describe the rules in your own words" → NEAR AI parses to exact fields for review/edit, never auto-submitted, client-side sanity validation before create_mandate

### Extras (Nov 13)
- [x] Hosted demo on Vercel (testnet): [meridian-zeta-murex.vercel.app](https://meridian-zeta-murex.vercel.app). Storage for `/break` attempts/scoreboard/rate-limits moved to Upstash Redis (Vercel Marketplace integration) with the local JSON file kept as the local-dev fallback. `dashboard/lib/near.ts`'s view calls are cached ~5s and go through a `FailoverRpcProvider` across two independent testnet RPC endpoints, since concurrent visitors polling the dashboard were hitting fastnear's public rate limit directly. `maxDuration` set on `/api/break`, `/api/mandates`, `/api/pending/[id]` and `/api/parse-mandate` so an LLM call plus a NEAR tx has room to finish. Verified live: dashboard and `/break` load, a real attack runs end to end (NEAR AI → `Vault.pay` → on-chain receipt), the scoreboard persists across requests, the 5-attempts/10-min rate limit returns 429, and `/api/mandates` signs and submits a real `create_mandate` tx from the deployed function.

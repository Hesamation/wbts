# Source excerpts relied on in REPORT.md

Short quotations for citation, with repository, commit and line numbers. Cloned 2026-11-14; the clones were removed from the workspace to keep it small. Re-clone at the commit to read in context.

## nearai/inference-proxy @ 3f7e979827065848bd26b71a85a40f29c2d27a60 (2026-11-13T23:33:21+01:00)

### src/routes/chat.rs L386-419 — which request hash is signed
```rust
/// Resolve SHA-256 hex digest to use as request_sha256 in signed text.
///
/// Default: hash of the wire body. When `allow_x_request_hash_override` is true
/// (caller authenticated with `config.token`, not `sk-`), if `X-Request-Hash` is
/// present, decodes to 32 bytes, and differs from the wire body hash, returns the
/// header value so trusted gateways that re-serialize JSON can bind signatures to
/// the original client body hash. When false, the header is ignored so end-user
/// API keys cannot bind signatures to an arbitrary hash.
pub fn resolve_request_hash_for_signing(
    headers: &HeaderMap,
    body_bytes: &[u8],
    allow_x_request_hash_override: bool,
) -> String {
    let body_hash = hex::encode(sha2::Sha256::digest(body_bytes));
    if !allow_x_request_hash_override {
        return body_hash;
    }
    // HeaderMap::get is case-insensitive; no need to try multiple spellings.
    if let Some(hv) = headers.get("x-request-hash") {
        if let Ok(s) = hv.to_str() {
            let s = s.trim();
            // hex::decode validates digits and rejects odd length; 32 bytes == SHA-256.
            if let Ok(bytes) = hex::decode(s) {
                if bytes.len() == 32 {
                    let header_hash = hex::encode(&bytes);
                    if header_hash != body_hash {
                        return header_hash;
                    }
                }
            }
        }
    }
    body_hash
}
```

### src/proxy.rs L2151-2158 — the signed text
```rust
    // Serialize with compact separators (matching Python's separators=(",",":"))
    let final_body =
        serde_json::to_string(&response_data).map_err(|e| AppError::Internal(e.into()))?;
    let response_sha256 = hex::encode(Sha256::digest(final_body.as_bytes()));

    // Sign and cache
    let text = format!("{}:{request_sha256}:{response_sha256}", opts.model_name);
    let signed = opts.signing.sign_chat(&text).map_err(|e| {
```

### src/signing.rs L66-74 — EIP-191 framing
```rust
    /// Sign a message using EIP-191 personal_sign format.
    /// Returns "0x{r}{s}{v}" (65 bytes hex-encoded).
    pub fn sign(&self, message: &str) -> Result<String> {
        // EIP-191: "\x19Ethereum Signed Message:\n{len}{message}"
        let prefix = format!("\x19Ethereum Signed Message:\n{}", message.len());
        let mut prefixed = Vec::with_capacity(prefix.len() + message.len());
        prefixed.extend_from_slice(prefix.as_bytes());
        prefixed.extend_from_slice(message.as_bytes());

```

### src/config.rs L1550 — signature cache lifetime default (seconds)
```rust
            chat_cache_expiration_secs: env_int("CHAT_CACHE_EXPIRATION", 1200) as u64,
```

### src/routes/signature.rs L29-36 — who may read a signature
```rust
    }
    // A configured TOKEN caller reads any signature. A direct customer key
    // reads only signatures recorded for its own organization and workspace;
    // anything else answers exactly like an unknown id.
    let owner = SignatureOwner::from_auth(&auth);
    let cache_value = SignatureReader::for_auth(&auth, owner.as_ref())
        .and_then(|reader| state.cache.get_chat(&chat_id, reader))
        .ok_or_else(|| AppError::NotFound("Chat id not found or expired".to_string()))?;
```

## nearai/cloud-api @ b26eb029e28537661fba7f7510d536e3f7325e2c (2026-11-13T16:45:21-08:00)

### crates/services/src/attestation/models.rs L81-91 — the two signature kinds
```rust
/// Which key produced a stored chat signature.
///
/// The two kinds sign different payloads:
/// - [`SignatureKind::ProviderTee`]: signed inside the model-serving TEE over
///   `"{model_id}:{request_hash}:{response_hash}"` (the provider's canonical
///   text), covering the exact bytes the model backend emitted.
/// - [`SignatureKind::Gateway`]: signed by the cloud-api gateway TEE over
///   `"{request_hash}:{response_hash}"`, covering the exact bytes the client
///   received. Used when the gateway rewrites the stream (usage accounting or
///   stripping, redaction), so the provider's byte-exact signature can no
///   longer match, and for attested providers without per-response signatures.
```

### crates/inference_providers/src/attested/nearai/mod.rs L1984-1986 — the gateway forwards the request hash as a header
```rust
        let request_hash_value = HeaderValue::from_str(&request_hash)
            .map_err(|e| CompletionError::CompletionError(format!("Invalid request hash: {e}")))?;
        headers.insert("X-Request-Hash", request_hash_value);
```

### crates/api/src/models.rs L20-45 (field names only) — unknown top-level request fields are kept, not rejected, by the gateway type
```rust
pub struct ChatCompletionRequest {
    pub model: String,
    pub messages: Vec<Message>,
    pub max_tokens: Option<i64>,
    pub temperature: Option<f32>,
    pub n: Option<i64>,
    pub stream: Option<bool>,
    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
```

## tmdry4530/tee-receipts @ 25cc88e01c9db037ad042c3bf3fa115646f627a0 (2026-11-02T02:49:10+09:00) (MIT)

Used only as the source of the two recorded receipts in probe/fixtures/third_party_tee_receipts/. Its testnet contract `tee-receipts-chamdom.testnet` was queried read-only (probe/live/testnet_third_party_contract_view.json).

## near-sdk 5.30.2 / near-sdk-env 0.1.9 (crates.io)

### near-sdk-5.30.2/src/environment/env.rs L595-596 — ecrecover is feature-gated
```rust
#[cfg(feature = "unstable")]
pub fn ecrecover(
```

### near-sdk-env-0.1.9/src/macros.rs L13-17 — host functions are used only when built with --cfg near
```rust
        #[cfg(any(
            all(near, target_arch = "wasm32"),
            all(feature = "__near-sdk-unit-testing", not(doctest))
        ))]
        $host_block
```

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.near.ai/llms.txt
> Use this file to discover all available pages before exploring further.

# SDK

> Call NEAR AI Cloud inference and verify responses in JavaScript, Python, Rust, and Go.

Use the NEAR AI Inference SDK to call models, verify attestation evidence, and check response signatures. Choose your language to get started:

> [card] [JavaScript](https://docs.near.ai/cloud/inference-sdk/javascript.md)
>
> Requires Node.js 24.22.1 or later.

> [card] [Python](https://docs.near.ai/cloud/inference-sdk/python.md)
>
> Requires Python 3.12 or later.

> [card] [Rust](https://docs.near.ai/cloud/inference-sdk/rust.md)
>
> Use Rust stable and Cargo.

> [card] [Go](https://docs.near.ai/cloud/inference-sdk/go.md)
>
> Requires Go 1.26.10 or later.

## Widget

Use the [Embedded](https://docs.near.ai/cloud/inference-sdk/widget/embedded.md) guide to add the Verification Center to your web application.

## Install

```bash JavaScript theme={"dark"}
npm install @nearai/inference-sdk
```

```bash Python theme={"dark"}
pip install nearai-inference-sdk
```

```bash Rust theme={"dark"}
cargo add nearai-inference-sdk
```

```bash Go theme={"dark"}
go get github.com/nearai/inference-sdk/go
```

## Supported APIs

Choose the API listed on your model's page in the [model catalog](https://docs.near.ai/cloud/models.md), then open its example in your language guide. All four languages support the APIs below; Chat Completions, Responses, and Messages also support streaming.

| API | Encryption |
| - | - |
| Chat Completions | Optional E2EE and OHTTP |
| Responses | Optional OHTTP |
| Messages | Optional OHTTP |
| System One | HTTPS |

## E2EE

End-to-end encryption (E2EE) encrypts supported Chat fields to a verified model key. It is disabled by default and requires a supported NEAR TEE model. Enable it in your language's client options; leave it disabled for Responses, Messages, and System One.

## Verification

The SDK verifies Gateway attestation before sending a request and model attestation where supported. After receiving the answer, call `verifyResponse()` or your language's equivalent before using the output. For streaming, consume the entire stream first.

| API | ID to verify |
| - | - |
| Chat Completions | Completion `id`, including an ID from the stream |
| Responses | Response `id`; for streaming, `event.response.id` from `response.created` |
| Messages | Message `id`; for streaming, `event.message.id` from `message_start` |
| System One | `decisionId` in JavaScript, `decision_id` in Python/Rust, `DecisionID` in Go; captured from `X-Generation-Id` |

System One's receipt ID is separate from the upstream request ID. If a receipt is temporarily unavailable, retry verification on the same client with the same ID; do not resend inference. Response records expire after 60 minutes by default; verify before expiry or closing the client.

Check the returned signature kind:

* `provider_tee`: the verified model signer signed the request and response bytes.
* `gateway`: the verified Gateway signed those bytes. This does not verify model TEE execution.

Responses and Messages use Gateway signatures. See [Verification](https://docs.near.ai/cloud/verification) for custom policies and evidence requirements.

## OHTTP

OHTTP adds encryption between the client and the attested Gateway for Chat Completions, Responses, and Messages. It is optional, disabled by default, and requires Ed25519. See the [JavaScript](https://docs.near.ai/cloud/inference-sdk/javascript.md#ohttp), [Python](https://docs.near.ai/cloud/inference-sdk/python.md#ohttp), [Rust](https://docs.near.ai/cloud/inference-sdk/rust.md#ohttp), or [Go](https://docs.near.ai/cloud/inference-sdk/go.md#ohttp) configuration.

## Examples

* [SDK examples](https://github.com/nearai/inference-sdk/tree/main/examples): complete projects for each language.
* [Image provenance examples](https://github.com/nearai/inference-sdk/tree/main/examples#image-provenance): check image builds and Compose Manager deployment evidence against your policies.


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.
# Attachments to REPORT.md

- `probe/` — everything that was executed: contract, harness, evidence checks, cost script, inputs and results. Start with `probe/README.md`; rerun with `probe/reproduce.sh`.
- `sources/` — copies of the documents the report cites, as fetched on 2026-11-14: organizer rules and track prompts, NEAR AI Cloud verification docs and terms, Agent Market docs and OpenAPI, READMEs of the hackathon entries sampled, and short code excerpts with commit hashes (`sources/excerpts/CODE_EXCERPTS.md`).

Nothing here needs a key, an account or a deployment.
